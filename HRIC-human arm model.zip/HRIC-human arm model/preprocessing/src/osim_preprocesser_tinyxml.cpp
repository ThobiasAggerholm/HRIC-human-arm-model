#include <ros/ros.h>
#include <ros/package.h>
#include <tinyxml2.h>
#include <iostream>
#include <sstream>
#include <eigen3/Eigen/Eigen>
#include <cassert>
#include <string>

struct EulerTransformString
{
  std::string xyz_rotation;
  std::string translation;
};


Eigen::Quaterniond 
eulerToQuaterion(const std::vector<double> &xyz_rotation)
{
  assert(xyz_rotation.size() == 3);
  Eigen::Quaterniond q_rotation = 
              Eigen::AngleAxisd(xyz_rotation[0], Eigen::Vector3d::UnitX())
              * Eigen::AngleAxisd(xyz_rotation[1], Eigen::Vector3d::UnitY())
              * Eigen::AngleAxisd(xyz_rotation[2], Eigen::Vector3d::UnitZ());

  return q_rotation;
}

Eigen::Transform<double, 3, Eigen::Projective> 
eulerToTransform(const std::vector<double>  &xyz_rotation, const std::vector<double>  &xyz_translation)
{
  assert(xyz_rotation.size() == 3);
  assert(xyz_translation.size() == 3);
  Eigen::Quaterniond q_rotation = eulerToQuaterion(xyz_rotation);
  Eigen::Matrix3d rotation = q_rotation.toRotationMatrix();
  Eigen::Translation3d translation(xyz_translation[0], xyz_translation[1], xyz_translation[2]);

  return translation * rotation;
            
}
Eigen::Transform<double, 3, Eigen::Projective> 
vectToTransformd(const std::vector<double> &vec)
{
    Eigen::Transform<double, 3, Eigen::Projective> transform;
    transform.matrix().setZero();

    if(!(vec.size() == 12))
    {
        return transform;
    }
    for(int i = 0; i < vec.size(); ++i)
    {
        transform(int(i / 4), i % 4) = vec[i];
    }
    transform(3,3) = 1.0;

    return transform;
}

EulerTransformString transformEulerTransform(const std::string &xyz_rotation, const std::string &translation, Eigen::Transform<double, 3, Eigen::Projective>& transform)
{
  std::vector<double> vxyz_rotation;
  // Build an istream that holds the input string
  std::istringstream xyz(xyz_rotation);
  // Iterate over the istream, using >> to grab floats
  // and push_back to store them in the vector
  std::copy(std::istream_iterator<double>(xyz),
        std::istream_iterator<double>(),
        std::back_inserter(vxyz_rotation));

  std::vector<double> vtranslation;
  // Build an istream that holds the input string
  std::istringstream trans(translation);
  // Iterate over the istream, using >> to grab floats
  // and push_back to store them in the vector
  std::copy(std::istream_iterator<double>(trans),
        std::istream_iterator<double>(),
        std::back_inserter(vtranslation));
  
  Eigen::Transform<double, 3, Eigen::Projective> stringTransform = eulerToTransform(vxyz_rotation, vtranslation);
  stringTransform = transform * stringTransform;

  Eigen::Matrix3d rotation = stringTransform.matrix().block(0,0,3,3);
  Eigen::Vector3d euler = rotation.eulerAngles(0, 1, 2);

  Eigen::Vector3d vetranslation = stringTransform.matrix().block(0,3,3,1);

  EulerTransformString result;
  result.xyz_rotation = std::to_string(euler(0)) + " " + std::to_string(euler(1)) + " " + std::to_string(euler(2));
  result.translation = std::to_string(vetranslation(0)) + " " + std::to_string(vetranslation(1)) + " " + std::to_string(vetranslation(2));

  return result;
}

std::string transformEulerTransform(const std::string &stringTransform, Eigen::Transform<double, 3, Eigen::Projective>& transform)
{
  std::vector<double> vtransform;
  // Build an istream that holds the input string
  std::istringstream transf(stringTransform);
  // Iterate over the istream, using >> to grab floats
  // and push_back to store them in the vector
  std::copy(std::istream_iterator<double>(transf),
        std::istream_iterator<double>(),
        std::back_inserter(vtransform));

  assert(vtransform.size() == 6);
  std::vector<double> vxyz_rotation = {vtransform[0], vtransform[1], vtransform[2]};
  std::vector<double> vtranslation = {vtransform[3], vtransform[4], vtransform[5]};
  
  Eigen::Transform<double, 3, Eigen::Projective> currentTransform = eulerToTransform(vxyz_rotation, vtranslation);
  currentTransform = transform * currentTransform;


  Eigen::Matrix3d rotation = currentTransform.matrix().block(0,0,3,3);
  Eigen::Vector3d euler = rotation.eulerAngles(0, 1, 2);
  Eigen::Vector3d vetranslation = currentTransform.matrix().block(0,3,3,1);

  EulerTransformString result;
  result.xyz_rotation = std::to_string(euler(0)) + " " + std::to_string(euler(1)) + " " + std::to_string(euler(2));
  result.translation = std::to_string(vetranslation(0)) + " " + std::to_string(vetranslation(1)) + " " + std::to_string(vetranslation(2));

  return std::to_string(euler(0)) + " " + std::to_string(euler(1)) + " " + std::to_string(euler(2)) + " " + std::to_string(vetranslation(0)) + " " + std::to_string(vetranslation(1)) + " " + std::to_string(vetranslation(2));
}

std::string transformPointTransform(const std::string &point, Eigen::Transform<double, 3, Eigen::Projective>& transform)
{
  std::vector<double> vpoint;
  // Build an istream that holds the input string
  std::istringstream pointis(point);
  // Iterate over the istream, using >> to grab floats
  // and push_back to store them in the vector
  std::copy(std::istream_iterator<double>(pointis),
        std::istream_iterator<double>(),
        std::back_inserter(vpoint));

  Eigen::Vector4d pointVector(vpoint[0], vpoint[1], vpoint[2], 1);

  pointVector = transform.matrix() * pointVector.matrix();
  
  return std::to_string(pointVector(0)) + " " + std::to_string(pointVector(1)) + " " + std::to_string(pointVector(2));
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "osim_preprocesser");
  ros::NodeHandle n;


  std::map<std::string, Eigen::Transform<double, 3, Eigen::Projective>> t_urdf_osim;
  t_urdf_osim["ground"] = vectToTransformd({0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0});
  t_urdf_osim["clavicle"] = vectToTransformd({0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0});
  t_urdf_osim["clavphant"] = vectToTransformd({0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0});
  t_urdf_osim["scapula"] = vectToTransformd({0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0});
  t_urdf_osim["scapphant"] = vectToTransformd({0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0});
  t_urdf_osim["humphant"] = vectToTransformd({0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0});
  t_urdf_osim["humphant1"] = vectToTransformd({0, 0, 1, 0, 0, 1, 0, 0, -1, 0, 0, 0});
  t_urdf_osim["humerus"] = vectToTransformd({-1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0.2904});
  t_urdf_osim["ulna"] = vectToTransformd({1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, -0.0200});
  t_urdf_osim["radius"] = vectToTransformd({-0.5621, 0, 0.8271, 0, 0.8271, 0, 0.5621, 0, 0, 1, 0, 0.2460});
  t_urdf_osim["proximal_row"] = vectToTransformd({0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0});
  t_urdf_osim["hand"] = vectToTransformd({1, 0, 0, 0.0044, 0, 1, 0, 0.065, 0, 0, 1, 0.0024});


  const std::string osim_filename = "MoBL_ARMS_module2_4_allmuscles_fc.osim";
  const std::string osim_dir_path = ros::package::getPath("preprocessing") + "/osim" + "/";
  const std::string muscles_filename = "muscles.osim";
  tinyxml2::XMLDocument osim;
  bool isLoaded = osim.LoadFile((osim_dir_path + osim_filename).c_str());

  // Get root Element
  tinyxml2::XMLElement * pRootElement = osim.RootElement();
  if (NULL == pRootElement) {   
    ROS_ERROR("Could not load osim file.");
    return 1;
  }

  tinyxml2::XMLDocument muscles;

  tinyxml2::XMLNode * declaration = osim.FirstChild()->ShallowClone(&muscles);
  muscles.InsertFirstChild(declaration);


  tinyxml2::XMLNode * opensimDocumentNode = pRootElement->ShallowClone(&muscles);
  tinyxml2::XMLElement * modelElement = pRootElement->FirstChildElement("Model");

  tinyxml2::XMLNode * modelNode = modelElement->ShallowClone(&muscles);
  opensimDocumentNode->InsertFirstChild(modelNode);

  //Not adding point actuator default value as this breaks the hybrid simulator
  tinyxml2::XMLNode * defaultsNode = modelElement->FirstChildElement("defaults")->ShallowClone(&muscles);
  tinyxml2::XMLElement * defaultChildElement = modelElement->FirstChildElement("defaults")->FirstChildElement();
  
  while (defaultChildElement)
  {
    
    if(std::string(defaultChildElement->Value()) == std::string("PointActuator"))
    {
      defaultChildElement = defaultChildElement->NextSiblingElement();
      continue;
    }
    defaultsNode->InsertEndChild(defaultChildElement->DeepClone(&muscles));

    defaultChildElement = defaultChildElement->NextSiblingElement();
  }
  
  modelNode->InsertFirstChild(defaultsNode);

  tinyxml2::XMLNode * creditsNode = modelElement->FirstChildElement("credits")->DeepClone(&muscles);
  modelNode->InsertEndChild(creditsNode);

  tinyxml2::XMLNode * publicationsNode = modelElement->FirstChildElement("publications")->DeepClone(&muscles);
  modelNode->InsertEndChild(publicationsNode);

  tinyxml2::XMLNode * length_unitsNode = modelElement->FirstChildElement("length_units")->DeepClone(&muscles);
  modelNode->InsertEndChild(length_unitsNode);

  tinyxml2::XMLNode * force_unitsNode = modelElement->FirstChildElement("force_units")->DeepClone(&muscles);
  modelNode->InsertEndChild(force_unitsNode);

  tinyxml2::XMLNode * gravityNode = modelElement->FirstChildElement("gravity")->DeepClone(&muscles);
  modelNode->InsertEndChild(gravityNode);

  tinyxml2::XMLNode * bodysetNode = modelElement->FirstChildElement("BodySet")->ShallowClone(&muscles);
  modelNode->InsertEndChild(bodysetNode);

  tinyxml2::XMLElement * bodysetElement = modelElement->FirstChildElement("BodySet");

  tinyxml2::XMLNode * objectsNode = bodysetElement->FirstChildElement("objects")->ShallowClone(&muscles);
  bodysetNode->InsertFirstChild(objectsNode);

  tinyxml2::XMLElement * objectsElement = bodysetElement->FirstChildElement("objects");
  tinyxml2::XMLElement * bodyElement = objectsElement->FirstChildElement("Body");
  
  while(bodyElement)
  {
    tinyxml2::XMLNode * bodyNode = bodyElement->ShallowClone(&muscles);
    //Edit xyz_rotation, translation and transform 

    objectsNode->InsertEndChild(bodyNode);

    tinyxml2::XMLNode * wrapobjectsetNode = bodyElement->FirstChildElement("WrapObjectSet")->DeepClone(&muscles);
    bodyNode->InsertEndChild(wrapobjectsetNode);

    bodyElement = bodyElement->NextSiblingElement("Body");
  }

  tinyxml2::XMLNode * forcesetNode = modelElement->FirstChildElement("ForceSet")->DeepClone(&muscles);
  modelNode->InsertEndChild(forcesetNode);

  tinyxml2::XMLElement * mbodyElement = objectsNode->FirstChildElement("Body");

  while (mbodyElement)
  {
    std::string mbodyName = mbodyElement->Attribute("name");

    tinyxml2::XMLElement * mWrapObject = mbodyElement->FirstChildElement("WrapObjectSet")->FirstChildElement("objects")->FirstChildElement();
    while(mWrapObject)
    {
      
      tinyxml2::XMLElement * mxyzbodyrotationElement = mWrapObject->FirstChildElement("xyz_body_rotation");
      tinyxml2::XMLElement * mtranslationElement = mWrapObject->FirstChildElement("translation");

      std::string xyzString = mxyzbodyrotationElement->GetText();
      std::string translationString = mtranslationElement->GetText();

      EulerTransformString newStrings = transformEulerTransform(xyzString, translationString, t_urdf_osim[mbodyName]);

      mxyzbodyrotationElement->SetText(newStrings.xyz_rotation.c_str());
      mtranslationElement->SetText(newStrings.translation.c_str());

      tinyxml2::XMLElement * mtransformElement = mWrapObject->FirstChildElement("VisibleObject")->FirstChildElement("transform");
      std::string transformString = mtransformElement->GetText();

      transformString = transformEulerTransform(transformString, t_urdf_osim[mbodyName]);

      mtransformElement->SetText(transformString.c_str());

      mWrapObject = mWrapObject->NextSiblingElement();
    } 
    mbodyElement = mbodyElement->NextSiblingElement("Body");
  }

  tinyxml2::XMLElement * Schutte1993Muscle_Deprecated = forcesetNode->FirstChildElement("objects")
                                                        ->FirstChildElement("Schutte1993Muscle_Deprecated");
  while(Schutte1993Muscle_Deprecated)
  {
    tinyxml2::XMLElement * pathpoint = Schutte1993Muscle_Deprecated->FirstChildElement("GeometryPath")->FirstChildElement("PathPointSet")
                                      ->FirstChildElement("objects")->FirstChildElement();
    while(pathpoint)
    {
      
      if(std::string(pathpoint->Value()) == std::string("MovingPathPoint") 
        || std::string(pathpoint->Value()) == std::string("ConditionalPathPoint") )
      {
        tinyxml2::XMLElement * notWorkingHybridPathPoint = pathpoint;

        pathpoint = pathpoint->NextSiblingElement();

        Schutte1993Muscle_Deprecated->FirstChildElement("GeometryPath")->FirstChildElement("PathPointSet")
                                      ->FirstChildElement("objects")->DeleteChild(notWorkingHybridPathPoint);
          
        
        continue;
      }
      
      std::string pathpoint_body_name = pathpoint->FirstChildElement("body")->GetText();
      std::string pathpoint_coordinate = pathpoint->FirstChildElement("location")->GetText();

      std::string at = pathpoint->Attribute("name");

      pathpoint_coordinate = transformPointTransform(pathpoint_coordinate, t_urdf_osim[pathpoint_body_name]);   
      

      pathpoint->FirstChildElement("location")->SetText(pathpoint_coordinate.c_str());
     
      pathpoint = pathpoint->NextSiblingElement();
    }

    Schutte1993Muscle_Deprecated = Schutte1993Muscle_Deprecated->NextSiblingElement("Schutte1993Muscle_Deprecated");
  }

  
  

  //Edit Pathpoints transform

  muscles.InsertEndChild(opensimDocumentNode);
  muscles.SaveFile((osim_dir_path + muscles_filename).c_str());
    


  return 0;
}
