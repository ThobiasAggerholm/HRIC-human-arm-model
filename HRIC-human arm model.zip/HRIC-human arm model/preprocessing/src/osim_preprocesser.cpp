#include <ros/ros.h>
#include <ros/package.h>
#include <OpenSim/OpenSim.h>
#include <eigen3/Eigen/Eigen>
#include <map>
#include <string>
#include <cassert>

//TODO check memory leaks
class mWrapObject : OpenSim::WrapObject
{

};

Eigen::Quaterniond 
eulerToQuaterion(const SimTK::Vec3 &xyz_rotation)
{
    Eigen::Quaterniond q_rotation = 
                Eigen::AngleAxisd(xyz_rotation(0), Eigen::Vector3d::UnitX())
                * Eigen::AngleAxisd(xyz_rotation(1), Eigen::Vector3d::UnitY())
                * Eigen::AngleAxisd(xyz_rotation(2), Eigen::Vector3d::UnitZ());
    return q_rotation;
}

Eigen::Transform<double, 3, Eigen::Projective> 
eulerToTransform(const SimTK::Vec3 &xyz_rotation, const SimTK::Vec3 &xyz_translation)
{
            
            Eigen::Quaterniond q_rotation = eulerToQuaterion(xyz_rotation);
            Eigen::Matrix3d rotation = q_rotation.toRotationMatrix();
            Eigen::Translation3d translation(xyz_translation(0), xyz_translation(1), xyz_translation(2));

            return translation * rotation;
            
}
Eigen::Transform<double, 3, Eigen::Projective> 
vectToTransformd(const std::vector<double> &vec)
{
    Eigen::Transform<double, 3, Eigen::Projective> transform;
    if(!(vec.size() == 12))
    {
        return transform;
    }
    for(int i = 0; i < vec.size(); ++i)
    {
        transform(int(i / 4), i % 4) = vec[i];
    }
    return transform;
}




int main(int argc, char **argv)
{
    ros::init(argc, argv, "osim_preprocesser");
    ros::NodeHandle n;

    std::map<std::string, Eigen::Transform<double, 3, Eigen::Projective>> t_urdf_osim;
    t_urdf_osim["clavicle"] = vectToTransformd({0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0});
    t_urdf_osim["clavphant"] = vectToTransformd({0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0});
    t_urdf_osim["scapula"] = vectToTransformd({0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0});
    t_urdf_osim["scapphant"] = vectToTransformd({0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0});
    t_urdf_osim["humphant"] = vectToTransformd({0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0});
    t_urdf_osim["humphant1"] = vectToTransformd({0, 0, 1, 0, 0, 1, 0, 0, -1, 0, 0, 0});
    t_urdf_osim["humerus"] = vectToTransformd({-1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0.2904});
    t_urdf_osim["ulna"] = vectToTransformd({1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, -0.0200});
    t_urdf_osim["radius"] = vectToTransformd({-0.5621, 0, 0.8271, 0, 0.8271, 0, 0.5621, 0, 0, 1, 0, 0.2460});
    t_urdf_osim["proximal_row"] = vectToTransformd({0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0});
    t_urdf_osim["hand"] = vectToTransformd({1, 0, 0, 0.0044, 0, 1, 0, 0.065, 0, 0, 1, 0.0024});






    const std::string osim_filename = "MoBL_ARMS_module2_4_allmuscles_fc.osim";
    const std::string osim_dir_path = ros::package::getPath("preprocessing") + "/osim" + "/";
    const std::string osim_file_path = osim_dir_path + osim_filename;

    OpenSim::Model osim_full_model(osim_file_path);
    OpenSim::Model osim_muscle_model;
    
    const OpenSim::BodySet osim_full_model_bodyset = osim_full_model.getBodySet();
    for(int i = 0; i < osim_full_model_bodyset.getSize(); ++i)
    {
        OpenSim::Body body = osim_full_model_bodyset.get(i);
        auto body_ptr = new OpenSim::Body; //Model does not allow me to free. This should not mattter in this app.
        body_ptr->setName(body.getName());
        const OpenSim::WrapObjectSet wrap_object_set = body.getWrapObjectSet();

        Eigen::Transform<double, 3, Eigen::Projective> body_urdf_osim;
        body_urdf_osim = t_urdf_osim[body_ptr->getName()];
        for(int j = 0; j < wrap_object_set.getSize(); ++j)
        {
            OpenSim::WrapObject* wrap_object = wrap_object_set.get(j).clone();
            SimTK::Vec3 wrap_xyz_rotation = {wrap_object->getXYZBodyRotation()[0],
            wrap_object->getXYZBodyRotation()[1], wrap_object->getXYZBodyRotation()[2]};

            SimTK::Vec3 wrap_translation = {wrap_object->getTranslation()[0],
             wrap_object->getTranslation()[1], wrap_object->getTranslation()[2]};


            Eigen::Transform<double, 3, Eigen::Projective> transform;
            transform = eulerToTransform(wrap_xyz_rotation, wrap_translation);
            transform = body_urdf_osim * transform;
            
            Eigen::Vector3d euler_xyz = transform.rotation().eulerAngles(0, 1, 2);
            Eigen::Vector3d translation_xyz = transform.translation();

            double _xyz_rotation[3] = {euler_xyz(0), euler_xyz(1), euler_xyz(2)};
            double _translation[3] = {translation_xyz(0), translation_xyz(1), translation_xyz(2)};

            std::cout << body_ptr->getName() << std::endl;
            std::cout << wrap_object->getWrapTypeName() << std::endl;
            std::cout << "before rotation: " << wrap_xyz_rotation(0) << "x" << wrap_xyz_rotation(1) << "x" << wrap_xyz_rotation(2) << std::endl;
            std::cout << "before translation: " << wrap_translation(0) << "x" << wrap_translation(1) << "x" << wrap_translation(2) << std::endl;
            std::cout << "after rotation: " << euler_xyz(0) << _xyz_rotation[0] << "x" << _xyz_rotation[1] << "x" << _xyz_rotation[2] << std::endl;
            std::cout << "after translation: " << _translation[0] << "x" << _translation[1] << "x" << _translation[2] << std::endl;

            //CONST CAST USE WITH CARE
            double* wrap_object_xyz_rotation = const_cast<double*>(wrap_object->getXYZBodyRotation());
            wrap_object_xyz_rotation = _xyz_rotation;
            double* wrap_object_translation = const_cast<double*>(wrap_object->getTranslation());
            wrap_object_translation = _translation;
            
            body_ptr->addWrapObject(wrap_object);
            
        }
        
        osim_muscle_model.addBody(body_ptr);
    }
    
    /*OpenSim::ForceSet sim_full_model_forceset = osim_full_model.upd_ForceSet();
    sim_full_model_forceset.extendConnectToModel(osim_full_model);
    const OpenSim::Set<OpenSim::Muscle> muscleset = sim_full_model_forceset.getMuscles();
    for(int i = 0; i < muscleset.getSize(); ++i)
    {
        OpenSim::PathPointSet pathpointset = muscleset.get(i).upd_GeometryPath().updPathPointSet();
        for(int j = 0; j < pathpointset.getSize(); ++j)
        {
            ROS_INFO("try this");
            bool l = muscleset.get(i).get_GeometryPath().getPathPointSet().get(j).getSocket("parent_frame").isConnected();
            ROS_INFO("Is connected %i", l);
            muscleset.get(i).get_GeometryPath().getPathPointSet().get(j).getParentFrame();
            ROS_INFO("Is connected %i", l);

            
            std::string classname = pathpointset.get(j).getConcreteClassName();
            OpenSim::AbstractPathPoint* abstractpathpoint = pathpointset.get(j).clone();
            if(abstractpathpoint->getConcreteClassName() == "PathPoint")
            {
                OpenSim::PathPoint* pathpoint;
                pathpoint = dynamic_cast<OpenSim::PathPoint*>(abstractpathpoint);
                SimTK::Vec3 location = pathpoint->upd_location();
                ROS_INFO("%s", pathpoint->getName().c_str());
                abstractpathpoint->getParentFrame();
                return 0;

            }


        }
    }*/
    //osim_muscle_model.set_ForceSet(osim_full_model.get_ForceSet());

    const std::string model_path = osim_dir_path + "muscles.osim";
    osim_muscle_model.print(model_path);
    

  return 0;
}
