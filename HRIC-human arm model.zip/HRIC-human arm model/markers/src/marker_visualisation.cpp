#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <tf2_msgs/TFMessage.h>
class Marker_visualiser
{
    public:
    Marker_visualiser()
    {
        marker_pub = n.advertise<visualization_msgs::Marker>("visualization_marker", 10);

        XmlRpc::XmlRpcValue marker_human_arm_dict;
        std::string param_human_arm_markers_path = "markers/human_arm_markers/";
        if (!n.getParam(param_human_arm_markers_path, marker_human_arm_dict))
        {
            ROS_ERROR("Could not load params from %s.", param_human_arm_markers_path.c_str());
            throw "Could not load params from " + param_human_arm_markers_path;
        }

        for (XmlRpc::XmlRpcValue::const_iterator const_it_joint = marker_human_arm_dict.begin(); const_it_joint != marker_human_arm_dict.end(); ++const_it_joint)
        {
            for (XmlRpc::XmlRpcValue::const_iterator const_it_marker = const_it_joint->second.begin(); const_it_marker != const_it_joint->second.end(); ++const_it_marker)
            {
                geometry_msgs::TransformStamped msg;
                msg.header.seq = 0;
                msg.header.stamp = ros::Time::now();
                msg.header.frame_id = const_it_joint->first;
                msg.child_frame_id = const_it_marker->first;

                double x = marker_human_arm_dict[const_it_joint->first][const_it_marker->first]["x"];
                msg.transform.translation.x = x;
                double y = marker_human_arm_dict[const_it_joint->first][const_it_marker->first]["y"];
                msg.transform.translation.y = y;
                double z = marker_human_arm_dict[const_it_joint->first][const_it_marker->first]["z"];
                msg.transform.translation.z = z;

                double qx = marker_human_arm_dict[const_it_joint->first][const_it_marker->first]["qx"];
                msg.transform.rotation.x = qx;
                double qy = marker_human_arm_dict[const_it_joint->first][const_it_marker->first]["qy"];
                msg.transform.rotation.y = qy;
                double qz = marker_human_arm_dict[const_it_joint->first][const_it_marker->first]["qz"];
                msg.transform.rotation.z = qz;
                double qw = marker_human_arm_dict[const_it_joint->first][const_it_marker->first]["qw"];
                msg.transform.rotation.w = qw;

                marker_transforms.transforms.push_back(msg);
            }
        }
    }

    void publish_marker_visualisation()
    {
        for (geometry_msgs::TransformStamped marker_state : marker_transforms.transforms)
        {
            visualization_msgs::Marker marker;
            marker.header.frame_id = marker_state.header.frame_id;
            marker.header.stamp = ros::Time::now();

            // Set the namespace and id for this marker.  This serves to create a unique ID
            // Any marker sent with the same namespace and id will overwrite the old one
            marker.ns = marker_state.child_frame_id;
            marker.id = 0;

            // Set the marker type.  Initially this is CUBE, and cycles between that and SPHERE, ARROW, and CYLINDER
            marker.type = shape;

            // Set the marker action.  Options are ADD, DELETE, and new in ROS Indigo: 3 (DELETEALL)
            marker.action = visualization_msgs::Marker::ADD;

            // Set the pose of the marker.  This is a full 6DOF pose relative to the frame/time specified in the header
            marker.pose.position.x = marker_state.transform.translation.x;
            marker.pose.position.y = marker_state.transform.translation.y;
            marker.pose.position.z = marker_state.transform.translation.z;
            marker.pose.orientation.x = marker_state.transform.rotation.x;
            marker.pose.orientation.y = marker_state.transform.rotation.y;
            marker.pose.orientation.z = marker_state.transform.rotation.z;
            marker.pose.orientation.w = marker_state.transform.rotation.w;

            // Set the scale of the marker -- 1x1x1 here means 1m on a side
            marker.scale.x = 0.03;
            marker.scale.y = 0.03;
            marker.scale.z = 0.03;

            // Set the color -- be sure to set alpha to something non-zero!
            marker.color.r = 1.0f;
            marker.color.g = 1.0f;
            marker.color.b = 0.0f;
            marker.color.a = 1.0;

            marker.lifetime = ros::Duration();

            marker_pub.publish(marker);
        }
    }

    private: 
    ros::NodeHandle n;
    ros::Publisher marker_pub;
    uint32_t shape = visualization_msgs::Marker::SPHERE;

    tf2_msgs::TFMessage marker_transforms;
};
int main(int argc, char **argv)
{
    ros::init(argc, argv, "marker_visualisation");
    ros::NodeHandle n;

    Marker_visualiser marker_visualiser;
    ros::Rate loop_rate(50);

    while (ros::ok())
    {
        marker_visualiser.publish_marker_visualisation();
        loop_rate.sleep();
    }
}
