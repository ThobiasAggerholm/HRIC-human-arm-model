#include <ros/ros.h>
#include <ros/package.h>
#include <iostream>
#include <sstream>
#include <eigen3/Eigen/Eigen>
#include <cassert>
#include <string>
#include <iomanip>

struct EulerTransformString
{
  std::string xyz_rotation;
  std::string translation;
};


Eigen::Quaterniond 
eulerToQuaterion(const std::vector<double> &xyz_rotation)
{
  assert(xyz_rotation.size() == 3);
  Eigen::Quaterniond q_rotation = 
              Eigen::AngleAxisd(xyz_rotation[0], Eigen::Vector3d::UnitX())
              * Eigen::AngleAxisd(xyz_rotation[1], Eigen::Vector3d::UnitY())
              * Eigen::AngleAxisd(xyz_rotation[2], Eigen::Vector3d::UnitZ());

  return q_rotation;
}

Eigen::Transform<double, 3, Eigen::Projective> 
eulerToTransform(const std::vector<double>  &xyz_rotation, const std::vector<double>  &xyz_translation)
{
  assert(xyz_rotation.size() == 3);
  assert(xyz_translation.size() == 3);
  Eigen::Quaterniond q_rotation = eulerToQuaterion(xyz_rotation);
  Eigen::Matrix3d rotation = q_rotation.toRotationMatrix();
  Eigen::Translation3d translation(xyz_translation[0], xyz_translation[1], xyz_translation[2]);

  return translation * rotation;
            
}
Eigen::Transform<double, 3, Eigen::Projective> 
vectToTransformd(const std::vector<double> &vec)
{
    Eigen::Transform<double, 3, Eigen::Projective> transform;
    transform.matrix().setZero();

    if(!(vec.size() == 12))
    {
        return transform;
    }
    for(int i = 0; i < vec.size(); ++i)
    {
        transform(int(i / 4), i % 4) = vec[i];
    }
    transform(3,3) = 1.0;

    return transform;
}

EulerTransformString transformEulerTransform(const std::string &xyz_rotation, const std::string &translation, Eigen::Transform<double, 3, Eigen::Projective>& transform)
{
  std::vector<double> vxyz_rotation;
  // Build an istream that holds the input string
  std::istringstream xyz(xyz_rotation);
  // Iterate over the istream, using >> to grab floats
  // and push_back to store them in the vector
  std::copy(std::istream_iterator<double>(xyz),
        std::istream_iterator<double>(),
        std::back_inserter(vxyz_rotation));

  std::vector<double> vtranslation;
  // Build an istream that holds the input string
  std::istringstream trans(translation);
  // Iterate over the istream, using >> to grab floats
  // and push_back to store them in the vector
  std::copy(std::istream_iterator<double>(trans),
        std::istream_iterator<double>(),
        std::back_inserter(vtranslation));
  
  Eigen::Transform<double, 3, Eigen::Projective> stringTransform = eulerToTransform(vxyz_rotation, vtranslation);
  stringTransform = transform * stringTransform;

  Eigen::Matrix3d rotation = stringTransform.matrix().block(0,0,3,3);
  Eigen::Vector3d euler = rotation.eulerAngles(0, 1, 2);

  Eigen::Vector3d vetranslation = stringTransform.matrix().block(0,3,3,1);

  EulerTransformString result;
  result.xyz_rotation = std::to_string(euler(0)) + " " + std::to_string(euler(1)) + " " + std::to_string(euler(2));
  result.translation = std::to_string(vetranslation(0)) + " " + std::to_string(vetranslation(1)) + " " + std::to_string(vetranslation(2));

  return result;
}

std::string transformEulerTransform(const std::string &stringTransform, Eigen::Transform<double, 3, Eigen::Projective>& transform)
{
  std::vector<double> vtransform;
  // Build an istream that holds the input string
  std::istringstream transf(stringTransform);
  // Iterate over the istream, using >> to grab floats
  // and push_back to store them in the vector
  std::copy(std::istream_iterator<double>(transf),
        std::istream_iterator<double>(),
        std::back_inserter(vtransform));

  assert(vtransform.size() == 6);
  std::vector<double> vxyz_rotation = {vtransform[0], vtransform[1], vtransform[2]};
  std::vector<double> vtranslation = {vtransform[3], vtransform[4], vtransform[5]};
  
  Eigen::Transform<double, 3, Eigen::Projective> currentTransform = eulerToTransform(vxyz_rotation, vtranslation);
  currentTransform = transform * currentTransform;


  Eigen::Matrix3d rotation = currentTransform.matrix().block(0,0,3,3);
  Eigen::Vector3d euler = rotation.eulerAngles(0, 1, 2);
  Eigen::Vector3d vetranslation = currentTransform.matrix().block(0,3,3,1);

  EulerTransformString result;
  result.xyz_rotation = std::to_string(euler(0)) + " " + std::to_string(euler(1)) + " " + std::to_string(euler(2));
  result.translation = std::to_string(vetranslation(0)) + " " + std::to_string(vetranslation(1)) + " " + std::to_string(vetranslation(2));

  return std::to_string(euler(0)) + " " + std::to_string(euler(1)) + " " + std::to_string(euler(2)) + " " + std::to_string(vetranslation(0)) + " " + std::to_string(vetranslation(1)) + " " + std::to_string(vetranslation(2));
}

std::string transformPointTransform(const std::string &point, Eigen::Transform<double, 3, Eigen::Projective>& transform)
{
  std::vector<double> vpoint;
  // Build an istream that holds the input string
  std::istringstream pointis(point);
  // Iterate over the istream, using >> to grab floats
  // and push_back to store them in the vector
  std::copy(std::istream_iterator<double>(pointis),
        std::istream_iterator<double>(),
        std::back_inserter(vpoint));

  Eigen::Vector4d pointVector(vpoint[0], vpoint[1], vpoint[2], 1);

  pointVector = transform.matrix() * pointVector.matrix();
  
  return std::to_string(pointVector(0)) + " " + std::to_string(pointVector(1)) + " " + std::to_string(pointVector(2));
}

std::string transformToString(const Eigen::Transform<double, 3, Eigen::Projective>& transform)
{
  Eigen::Matrix3d rotation = transform.matrix().block(0,0,3,3);
  Eigen::Vector3d euler = rotation.eulerAngles(0, 1, 2);

  Eigen::Vector3d vetranslation = transform.matrix().block(0,3,3,1);

  return std::to_string(vetranslation(0)) + " " + std::to_string(vetranslation(1)) + " " + std::to_string(vetranslation(2)) + " " + std::to_string(euler(0)) + " " + std::to_string(euler(1)) + " " + std::to_string(euler(2));
}
int main(int argc, char **argv)
{
  ros::init(argc, argv, "sdfPoseConverter");
  ros::NodeHandle n;
  std::vector<double> rot = {0, 0, 0};
  std::vector<double> tra ={0, 0, 0};
  Eigen::Transform<double, 3, Eigen::Projective> model_base = eulerToTransform(rot, tra);
  std::cout << "model base: " << transformToString(model_base) << std::endl;
  rot = {0, 0, 1.5708};
  tra ={0, 0, 0};
  Eigen::Transform<double, 3, Eigen::Projective> model_ground = model_base * eulerToTransform(rot, tra);
  std::cout << "model ground: " << transformToString(model_ground)<< std::endl;
  rot = {0, 0, 0};
  tra ={0.025465, 0.006325, 0.00693};
  Eigen::Transform<double, 3, Eigen::Projective> model_clavicle = model_ground * eulerToTransform(rot, tra);
  std::cout << "model clavicle: " << transformToString(model_clavicle)<< std::endl;
  rot = {0, 0, 0};
  tra ={0.135535, -0.01433, 0.02007};
  Eigen::Transform<double, 3, Eigen::Projective> model_clavphant = model_clavicle * eulerToTransform(rot, tra);
  std::cout << "model clavphant: " << transformToString(model_clavphant)<< std::endl;
  rot = {0, 0, 0};
  tra ={0, 0, 0};
  Eigen::Transform<double, 3, Eigen::Projective> model_scapula = model_clavphant * eulerToTransform(rot, tra);
  std::cout << "model_scapula: " << transformToString(model_scapula)<< std::endl;
  rot = {0, 0, 0};
  tra ={0.009, -0.00955, -0.034};
  Eigen::Transform<double, 3, Eigen::Projective> model_scapphant = model_scapula * eulerToTransform(rot, tra);
  std::cout << "model_scapphant: " << transformToString(model_scapphant)<< std::endl;
  rot = {0, 0, 0};
  tra ={0, 0, 0};
  Eigen::Transform<double, 3, Eigen::Projective> model_humphant = model_scapphant * eulerToTransform(rot, tra);
  std::cout << "model_humphant: " << transformToString(model_humphant)<< std::endl;
  rot = {1.5708, 0, 0};
  tra ={0, 0, 0};
  Eigen::Transform<double, 3, Eigen::Projective> model_humphant1 = model_humphant * eulerToTransform(rot, tra);
  std::cout << "model_humphant1: " << transformToString(model_humphant1)<< std::endl;
  rot = {-1.5708, 0, -1.5708};
  tra ={0, -0.2904, 0};
  Eigen::Transform<double, 3, Eigen::Projective> model_humerus = model_humphant1 * eulerToTransform(rot, tra);
  std::cout << "model_humerus: " << transformToString(model_humerus)<< std::endl;
  rot = {1.5708, 0, 3.14159};
  tra ={-0.0061, 0.0077, 0};
  Eigen::Transform<double, 3, Eigen::Projective> model_ulna = model_humerus * eulerToTransform(rot, tra);

  std::cout << "model_ulna: " << transformToString(model_ulna)<< std::endl;
  rot = {1.5708, -0.973894, -3.14159};
  tra ={0, -0.2575, 0};
  Eigen::Transform<double, 3, Eigen::Projective> model_radius = model_ulna * eulerToTransform(rot, tra);
  model_radius.matrix()(0,0) = 0.5621;
  model_radius.matrix()(0,1) = -0.8271;
  model_radius.matrix()(0,2) = 0;
  model_radius.matrix()(1,0) = 0.8271;
  model_radius.matrix()(1,1) = 0.5621;
  model_radius.matrix()(1,2) = 0;
  model_radius.matrix()(2,0) = 0;
  model_radius.matrix()(2,1) = 0;
  model_radius.matrix()(2,2) = 1;
  model_radius.matrix()(0,3) = 0.0115;
  model_radius.matrix()(1,3) = 0.1777;
  model_radius.matrix()(2,3) =-0.5549;
  std::cout << "model_radius: " << transformToString(model_radius)<< std::endl;
  rot = {-2.18091, -1.33166, -2.54497};
  tra ={-0.0105, 0.02893, 0.003963};
  Eigen::Transform<double, 3, Eigen::Projective> model_z6 = model_radius * eulerToTransform(rot, tra);
  std::cout << "model_z6: " << transformToString(model_z6)<< std::endl;
  rot = {-2.54422, 0.136266, -0.197095};
  tra ={0, 0, 0};
  Eigen::Transform<double, 3, Eigen::Projective> model_proximal_row = model_z6 * eulerToTransform(rot, tra);
  std::cout << " model_proximal_row: " << transformToString( model_proximal_row)<< std::endl;
  rot = {-1.5708, -1.5708, 0};
  tra ={-0.08, 0, 0};
  Eigen::Transform<double, 3, Eigen::Projective> model_hand= model_proximal_row * eulerToTransform(rot, tra);
  std::cout << " model_hand: " << transformToString( model_hand)<< std::endl;
 
  std::cout << "matrix:\n " << model_radius.matrix() << std::endl;


  return 0;
}
