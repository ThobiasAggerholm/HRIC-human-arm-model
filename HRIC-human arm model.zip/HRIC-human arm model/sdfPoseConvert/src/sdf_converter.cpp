#include <ros/ros.h>
#include <ros/package.h>
#include <iostream>
#include <sstream>
#include <eigen3/Eigen/Eigen>
#include <cassert>
#include <string>
#include <iomanip>
#include <geometric_transform.hpp>

struct EulerTransformString
{
  std::string xyz_rotation;
  std::string translation;
};


Eigen::Quaterniond 
eulerToQuaterion(const std::vector<double> &xyz_rotation)
{
  assert(xyz_rotation.size() == 3);
  Eigen::Quaterniond q_rotation = 
              Eigen::AngleAxisd(xyz_rotation[0], Eigen::Vector3d::UnitX())
              * Eigen::AngleAxisd(xyz_rotation[1], Eigen::Vector3d::UnitY())
              * Eigen::AngleAxisd(xyz_rotation[2], Eigen::Vector3d::UnitZ());

  return q_rotation;
}

Eigen::Transform<double, 3, Eigen::Projective> 
eulerToTransform(const std::vector<double>  &xyz_rotation, const std::vector<double>  &xyz_translation)
{
  assert(xyz_rotation.size() == 3);
  assert(xyz_translation.size() == 3);
  Eigen::Quaterniond q_rotation = eulerToQuaterion(xyz_rotation);
  Eigen::Matrix3d rotation = q_rotation.toRotationMatrix();
  Eigen::Translation3d translation(xyz_translation[0], xyz_translation[1], xyz_translation[2]);

  return translation * rotation;
            
}
Eigen::Transform<double, 3, Eigen::Projective> 
vectToTransformd(const std::vector<double> &vec)
{
    Eigen::Transform<double, 3, Eigen::Projective> transform;
    transform.matrix().setZero();

    if(!(vec.size() == 12))
    {
        return transform;
    }
    for(int i = 0; i < vec.size(); ++i)
    {
        transform(int(i / 4), i % 4) = vec[i];
    }
    transform(3,3) = 1.0;

    return transform;
}

EulerTransformString transformEulerTransform(const std::string &xyz_rotation, const std::string &translation, Eigen::Transform<double, 3, Eigen::Projective>& transform)
{
  std::vector<double> vxyz_rotation;
  // Build an istream that holds the input string
  std::istringstream xyz(xyz_rotation);
  // Iterate over the istream, using >> to grab floats
  // and push_back to store them in the vector
  std::copy(std::istream_iterator<double>(xyz),
        std::istream_iterator<double>(),
        std::back_inserter(vxyz_rotation));

  std::vector<double> vtranslation;
  // Build an istream that holds the input string
  std::istringstream trans(translation);
  // Iterate over the istream, using >> to grab floats
  // and push_back to store them in the vector
  std::copy(std::istream_iterator<double>(trans),
        std::istream_iterator<double>(),
        std::back_inserter(vtranslation));
  
  Eigen::Transform<double, 3, Eigen::Projective> stringTransform = eulerToTransform(vxyz_rotation, vtranslation);
  stringTransform = transform * stringTransform;

  Eigen::Matrix3d rotation = stringTransform.matrix().block(0,0,3,3);
  Eigen::Vector3d euler = rotation.eulerAngles(0, 1, 2);

  Eigen::Vector3d vetranslation = stringTransform.matrix().block(0,3,3,1);

  EulerTransformString result;
  result.xyz_rotation = std::to_string(euler(0)) + " " + std::to_string(euler(1)) + " " + std::to_string(euler(2));
  result.translation = std::to_string(vetranslation(0)) + " " + std::to_string(vetranslation(1)) + " " + std::to_string(vetranslation(2));

  return result;
}

std::string transformEulerTransform(const std::string &stringTransform, Eigen::Transform<double, 3, Eigen::Projective>& transform)
{
  std::vector<double> vtransform;
  // Build an istream that holds the input string
  std::istringstream transf(stringTransform);
  // Iterate over the istream, using >> to grab floats
  // and push_back to store them in the vector
  std::copy(std::istream_iterator<double>(transf),
        std::istream_iterator<double>(),
        std::back_inserter(vtransform));

  assert(vtransform.size() == 6);
  std::vector<double> vxyz_rotation = {vtransform[0], vtransform[1], vtransform[2]};
  std::vector<double> vtranslation = {vtransform[3], vtransform[4], vtransform[5]};
  
  Eigen::Transform<double, 3, Eigen::Projective> currentTransform = eulerToTransform(vxyz_rotation, vtranslation);
  currentTransform = transform * currentTransform;


  Eigen::Matrix3d rotation = currentTransform.matrix().block(0,0,3,3);
  Eigen::Vector3d euler = rotation.eulerAngles(0, 1, 2);
  Eigen::Vector3d vetranslation = currentTransform.matrix().block(0,3,3,1);

  EulerTransformString result;
  result.xyz_rotation = std::to_string(euler(0)) + " " + std::to_string(euler(1)) + " " + std::to_string(euler(2));
  result.translation = std::to_string(vetranslation(0)) + " " + std::to_string(vetranslation(1)) + " " + std::to_string(vetranslation(2));

  return std::to_string(euler(0)) + " " + std::to_string(euler(1)) + " " + std::to_string(euler(2)) + " " + std::to_string(vetranslation(0)) + " " + std::to_string(vetranslation(1)) + " " + std::to_string(vetranslation(2));
}

std::string transformPointTransform(const std::string &point, Eigen::Transform<double, 3, Eigen::Projective>& transform)
{
  std::vector<double> vpoint;
  // Build an istream that holds the input string
  std::istringstream pointis(point);
  // Iterate over the istream, using >> to grab floats
  // and push_back to store them in the vector
  std::copy(std::istream_iterator<double>(pointis),
        std::istream_iterator<double>(),
        std::back_inserter(vpoint));

  Eigen::Vector4d pointVector(vpoint[0], vpoint[1], vpoint[2], 1);

  pointVector = transform.matrix() * pointVector.matrix();
  
  return std::to_string(pointVector(0)) + " " + std::to_string(pointVector(1)) + " " + std::to_string(pointVector(2));
}

std::string transformToString(const Eigen::Transform<double, 3, Eigen::Projective>& transform)
{
  Eigen::Matrix3d rotation = transform.matrix().block(0,0,3,3);
  Eigen::Vector3d euler = rotation.eulerAngles(0, 1, 2);

  Eigen::Vector3d vetranslation = transform.matrix().block(0,3,3,1);

  return std::to_string(vetranslation(0)) + " " + std::to_string(vetranslation(1)) + " " + std::to_string(vetranslation(2)) + " " + std::to_string(euler(0)) + " " + std::to_string(euler(1)) + " " + std::to_string(euler(2));
}
void ht2ss_pose(Eigen::MatrixXd& ht)
{
  double x,y,z,ax,ay,az;
  Geometric_Transforms::ht2pose(x, y, z, ax, ay, az, ht);
  std::cout << x << " " << y << " " << z << " " << ax << " " << ay << " " << az << std::endl;
}
int main(int argc, char **argv)
{
  ros::init(argc, argv, "sdfPoseConverter");
  ros::NodeHandle n;
  Eigen::MatrixXd ht;
  ht = Geometric_Transforms::dh2ht(0.0, 0.0, 0.0, 0.0);
  std::cout << "base:" << std::endl;
  ht2ss_pose(ht);
  ht = ht * Geometric_Transforms::pose2ht(0.0, 0.0, 0.0, 0.0, 0.0, M_PI_2);
  std::cout << "ground:" << std::endl;
  ht2ss_pose(ht);
  ht = ht * Geometric_Transforms::pose2ht(0.0255, 0.0063, 0.0069, 0.0, 0.0, 0.0);
  std::cout << "clavicle:" << std::endl;
  ht2ss_pose(ht);
  ht = ht * Geometric_Transforms::pose2ht(0.1355, -0.0143, 0.0201, 0.0, 0.0, 0.0);
  std::cout << "clavphant:" << std::endl;
  ht2ss_pose(ht);
  ht = ht * Geometric_Transforms::pose2ht(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
  std::cout << "scapula:" << std::endl;
  ht2ss_pose(ht);
  ht = ht * Geometric_Transforms::pose2ht(0.0090, -0.0095, -0.0340, 0.0, 0.0, 0.0);
  std::cout << "scapphant:" << std::endl;
  ht2ss_pose(ht);
  ht = ht * Geometric_Transforms::dh2ht(0.0, 0.0, 0.0, 0.0);
  std::cout << "humphant:" << std::endl;
  ht2ss_pose(ht);
  ht = ht * Geometric_Transforms::dh2ht(0.0, M_PI_2, 0.0, 0.0);
  std::cout << "humphant1:" << std::endl;
  ht2ss_pose(ht);
  ht = ht * Geometric_Transforms::dh2ht(0.0, -M_PI_2, -0.2904, -M_PI_2);
  std::cout << "humerus:" << std::endl;
  ht2ss_pose(ht);
  ht = ht * Geometric_Transforms::dh2ht(-0.0061, -M_PI_2, 0.0200 - 0.0123, M_PI);
  std::cout << "ulna:" << std::endl;
  ht2ss_pose(ht);
  ht = ht * Geometric_Transforms::dh2ht(0.0, -M_PI_2, -0.0115 - 0.2420 - 0.0040, 2.168);
  std::cout << "radius:" << std::endl;
  ht2ss_pose(ht);
    ht = ht * Geometric_Transforms::dh2ht(0.0105, 1.71, -0.0292, 1.768);
  std::cout << "z6:" << std::endl;
  ht2ss_pose(ht);
    ht = ht * Geometric_Transforms::dh2ht(0.0, -2.531, 0.0, 0.239);
  std::cout << "proximal_row:" << std::endl;
  ht2ss_pose(ht);
    ht = ht * Geometric_Transforms::dh2ht(-0.08, -M_PI_2, 0.0, -M_PI_2);
    std::cout << "hand:" << std::endl;
    ht2ss_pose(ht);


  return 0;
}
