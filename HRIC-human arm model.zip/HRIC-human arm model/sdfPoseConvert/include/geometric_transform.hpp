#ifndef GEOMETRIC_TRANSFORM__HPP
#define GEOMETRIC_TRANSFORM_HPP
#include <eigen3/Eigen/Eigen>
#include <cmath>
#include <cassert>
namespace Geometric_Transforms
{
    using namespace std;
    Eigen::MatrixXd dh2ht(double a, double alpha, double d, double theta)
    {
        Eigen::MatrixXd ht(4,4);
        ht << cos(theta), -sin(theta), 0, a,
            sin(theta) * cos(alpha), cos(theta) * cos(alpha), -sin(alpha), -sin(alpha) * d,
            sin(theta) * sin(alpha), cos(theta) * sin(alpha), cos(alpha), cos(alpha)*d,
            0, 0, 0, 1;

        return ht;

    }

    Eigen::MatrixXd pose2ht(double x, double y, double z, double g, double b, double a)
    {
        Eigen::MatrixXd ht(4,4);
        ht << cos(a) * cos(b), cos(a) * sin(b) * sin(g) - sin(a) * cos(g), cos(a) * sin(b) * cos(g) + sin(a) * sin(g), x,
              sin(a) * cos(b), sin(a) * sin(b) * sin(g) + cos(a) * cos(g), sin(a) * sin(b) * cos(g) - cos(a) * sin(g), y,
            -sin(b), cos(b) * sin(b), cos(b)*cos(g), z,
            0, 0, 0, 1;

        return ht;
    }

    void ht2pose(double& x, double& y, double& z, double& ax, double& ay, double& az, const Eigen::MatrixXd& ht)
    {
        assert(ht.rows() == 4 && ht.cols() == 4);
        x = ht(0,3);
        y = ht(1,3);
        z = ht(2, 3);
        ay = atan2(-ht(2,0), sqrt(pow(ht(0,0),2) + pow(ht(1,0), 2)));
        if(ay == M_PI_2)
        {
            ax = atan2(ht(0,1), ht(1,1));
            az = 0;
        }
        else if(ay == - M_PI_2)
        {
            ax = - atan2(ht(0,1), ht(1,1));
            az = 0;
        }
        else{
            ax = atan2(ht(2,1)/cos(ay), ht(2,2)/cos(ay));
            az = atan2(ht(1,0)/cos(ay), ht(0,0/cos(ay)));
        }
        
    }
}


#endif