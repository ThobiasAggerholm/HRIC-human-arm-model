This package is dependent on EIGEN3, KDL and KDL parser. Check CMakeLists.txt and package.xml.
The rospackage has a single launch file.

I've tried to add as many comments as needed.

Tests and results are in the bottom of the "main" file which is called src/model_fit.cpp.

Any classes defined myself are in the namespace MC::. You can find the files in include/model_fiting/.


There are some other dependencies from other ROS packages. I've copied them over to the folder
dependencies/ so that you can see them too.

I've added functions that convert from KDL Rotation and Vector to Eigen Matrix and Vector.
These are defined in the file include/model_fitting/kdl2eig.hpp.

To change number of time steps i.e. measurements go to line 268 and change variable "time_steps".

Experimental joint configurations are generated on line 277 - 290. These are sinusoidal signals that remain slightly within the limits of each joint. Limits are defined in dependencies/human_arm_description.xacro.

Experimental local coordinates for each marker is defined in the file dependencies/human_arm_marker.yaml

Different "noise" elements are created. noise line 246 is used to create a local marker coordinate with at random distance to the ground truth local marker coordinate. Noise_measurement_length sets this distance limits (between 3 cm to 5 cm) line 256.

noise_sign line 260 is used for created random directions.

noise_joints line 251 adds random noise to the ground truth joint configurations to create en initial joint configuration.


Terminal will show q ground truth, q optimal, difference of q ground truth and optimal and differenceof d ground truth and optimal. Terminal will also show difference in marker position ground truth and optimal. Note ground truth is the experimental data as it is the initial data for optimisation that has added noise.

In the terminal the first derivative test norm values will be shown. This is for adjusting the tolerance if the program goes on infinite loops. This terminal output and tolerance adjustment are done in the file include/model_fitting/local_optimiser.hpp line 113 to 116.
In the terminal there will be a message for when the initial joint configuration has been found i.e. step 1 of the algorithm. If this message never comes it's stuck in an infinte loop. The tolerance for finding the initial joint configuration can be adjustet in include/model_fitting/local_optimiser.hpp on line 184.

Test code starts at line 226 in the src/model_fit.cpp.

Data is written to a file data/algortihm_results.csv.