#include <ros/ros.h>
#include <ros/package.h>
#include <kdl_parser/kdl_parser.hpp>
#include <urdf/model.h>
#include <marker.hpp>
#include <mcmodel.hpp>
#include <mcmodel_test.hpp>
#include <local_optimiser.hpp>
#include <memory>
#include <kdl/kdl.hpp>
#include <kdl/chainfksolverpos_recursive.hpp>
#include <kdl/chainjnttojacsolver.hpp>
#include <kdl/treejnttojacsolver.hpp>


#include <kdl/treefksolverpos_recursive.hpp>

#include <kdl2eig.hpp>

#include <random>
#include <cmath>
#include <fstream>

void writeEigenToCSV(std::ofstream& filestream, std::string& header, Eigen::MatrixXd& mat)
{
    filestream << header << "\n";
    for(int i = 0; i < mat.rows(); ++i)
    {
        for(int j = 0; j < mat.cols(); ++j)
        {
            filestream << mat(i,j) << ",";
        }
        filestream << "\n";
    }
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "model_fitter");
    ros::NodeHandle n;
    /////////////////////////////////////////////////////////////
    /*
    Prepare file for data collection.
    */
    ////////////////////////////////////////////////////////////
    const std::string data_dir_path = ros::package::getPath("model_fitting") + "/data" + "/";
    const std::string data_filename = "algorithm_result.csv";
    std::ofstream algorithm_result;
    algorithm_result.open(data_dir_path + data_filename);

    //////////////////////////////////////////////////////////////
    /*
    Collecting Marker local coordinates and reference frame from 
    human_arm_markers.yaml file. Each marker will be instatiated
    in an object defined in marker.hpp.
    */
    //////////////////////////////////////////////////////////////
    //Get marker parameters
    XmlRpc::XmlRpcValue marker_human_arm_dict;
    std::string param_human_arm_markers_path = "markers/human_arm_markers/";
    if (!n.getParam(param_human_arm_markers_path, marker_human_arm_dict))
    {
        ROS_ERROR("Could not load paraMC from %s.", param_human_arm_markers_path.c_str());
        throw "Could not load paraMC from " + param_human_arm_markers_path;
    }

    //////////////////////////////////////////////////////////////
    /*
    List containing marker information. Class MC::Marker is defined
    marker.hpp.
    MC::Marker contains local position in reference to a parent
    frame. Class also contains name of marker. Provides methods
    to obtain local marker position, name of parent frame and name
    of marker.
    */
    //////////////////////////////////////////////////////////////
    std::vector<std::shared_ptr<MC::Marker>> markers;

    //Create list of markers from yaml file.
    for (XmlRpc::XmlRpcValue::const_iterator marker_parent_it = marker_human_arm_dict.begin();
     marker_parent_it != marker_human_arm_dict.end(); ++marker_parent_it)
    {
        for(XmlRpc::XmlRpcValue::const_iterator marker_it = marker_parent_it->second.begin();
         marker_it != marker_parent_it->second.end(); ++marker_it)
        {
            double x,y,z = 0;
            for(XmlRpc::XmlRpcValue::const_iterator marker_coordinates_it = marker_it->second.begin();
             marker_coordinates_it != marker_it->second.end(); ++marker_coordinates_it)
            {
                if(marker_coordinates_it->first == "x")
                {
                x = marker_coordinates_it->second;
                }
                else if(marker_coordinates_it->first == "y")
                {
                y = marker_coordinates_it->second;
                }
                else if(marker_coordinates_it->first == "z")
                {
                z = marker_coordinates_it->second;
                }
            }
            std::shared_ptr<MC::Marker> marker_ptr(new MC::Marker(marker_it->first, marker_parent_it->first, {x, y, z}));
            markers.push_back(marker_ptr);            
        }
    }

    //////////////////////////////////////////////////////////////
    /*
    Obtain urdf model information from param server. URDF model 
    defined in human_arm_description.xacro. Model has 13 segments
    (excluding world link) and 7 joints.
    */
    //////////////////////////////////////////////////////////////

    //Get model description
    urdf::Model robot_description;
    std::string param_path = "/robot_description";
    if(!robot_description.initParam(param_path))
    {
        ROS_ERROR("%s", param_path.c_str());
    }

    //////////////////////////////////////////////////////////////
    /*
    Creating KDL objects Tree and Chain for solving forward kinematics
    and finding Jacobians.
    */
    //////////////////////////////////////////////////////////////

    //KDL tree
    KDL::Tree robot_description_tree;
    if (!kdl_parser::treeFromUrdfModel(robot_description, robot_description_tree))
    {
        ROS_ERROR("Failed to construct kdl tree");
        return 1;
    }

    //KDL Chain
    //Define chain base and tip
    KDL::Chain human_arm_chain;
    std::string base = "base_link";
    std::string tip = "Hand";
    if(!robot_description_tree.getChain(base, tip, human_arm_chain))
    {
        ROS_ERROR("Could not load chain from %s to %s.", base.c_str(), tip.c_str());
    }
    
    
    //Tests
    ///////////////////TEST 1
    //Test result from testing marker position resultet in no errors in calculated position
    //when d =[1, 1 ... 1]^T Test is code below.

    
    //////////////////////////TEST Code //////////////
    /*
    std::cout << "Creating tester model..." << std::endl;
    Eigen::VectorXd q_tester(human_arm_chain.getNrOfJoints());
    q_tester.setConstant(0.0);
    Eigen::VectorXd d_tester;
    d_tester.setOnes(human_arm_chain.getNrOfSegments() * 3 + 3 * markers.size());
    std::shared_ptr<MC::MCModel> model(new MC::MCModel(robot_description_tree, human_arm_chain, markers));
    std::cout << "Tester model created." << std::endl;
    std::cout << "Creating Tester..." << std::endl;
    MC::MCModel_Tester mcmodel_tester(model, human_arm_chain, markers);
    std::cout << "Tester created." << std::endl;
    std::cout << "Testing..." << std::endl;
    mcmodel_tester.test_position(q_tester, d_tester);
    std::cout << "Test finished." << std::endl;*/
    


    //////////////////////TEST 2

    //Test result when testing for finding optimal joint configuration resultet in
    /*
    q:
    -1.24987e-16
    3.26245e-31
    1.19479e-16
    3.96807e-20
    3.35585e-16
    2.62743e-16
    -2.01427e-16*/
    //Target joint configuration was q_target = [0.1 0.1 ... 0.1]^T
    //Search direction was:
    /*
    search direction:
      -12.77
    -8.79451e-14
     12.2073
    0.00405421
      34.287
     26.8446
      -20.58
    */
   //    These are the results after many iterations
    //Number of chain segments, joints, markers and scaling parameters where
    /*
        Number of segments: 13
        Number of joints: 7
        Number of markers: 10
        Number of scaling parameters: 69
        Creating virtual and experimental model.
        Dimensions of G_q_: 7x1
        Dimensions of G_d_: 69x1
        Dimensions of G_qq_: 7x7
        Dimensions of G_dd_: 69x69
        Dimensions of G_dq_: 69x7
    */
   //Dimensions of objective function and derivatives where
   /*
        Dimensions of G_q_: 7x1
        Dimensions of G_d_: 69x1
        Dimensions of G_qq_: 7x7
        Dimensions of G_dd_: 69x69
        Dimensions of G_dq_: 69x7
   */
    /*std::cout << "Number of segments: " << robot_description_tree.getNrOfSegments() -1 << "\n";
    std::cout << "Number of joints: " << robot_description_tree.getNrOfJoints() << "\n";
    std::cout << "Number of markers: " << markers.size() << "\n";
    std::cout << "Number of scaling parameters: " << (robot_description_tree.getNrOfSegments() -1) * 3 + markers.size() * 3 << std::endl;*/
    /*

    ///////////////////Test code//////////////////

    //////////////////////////////////////////////////////////////
    /*
    Creates an MCModel that is repsonsible for calculateing global marker
    positions and giving psi_d and psi_q. MCModel takes KDL::Tree to instatiate
    so that KDL forward kinematics and Jacobian methods can be utilized.
    It also takes KDL::Chain to establish tree segment order. As a third
    parameter it takes the list of MC::Marker objects that contain local
    marker positions. The model provides methods to get global positoning
    and derivatives with respect to joint configuration and scaling parameters.
    It also provides a method called "update" that will update data structures
    at new joint configurations and scaling parameters.
    */
    //////////////////////////////////////////////////////////////

    
    //Random generator for creating noise.
    std::default_random_engine generator;
    std::uniform_real_distribution<> distribution(-1.0,1.0);
    auto noise = std::bind ( distribution, generator );

    //This determines the variation on experimental and initial data for the joint configuration
    //Sign is determined by noise_sign line 234
    std::uniform_real_distribution<> distribution_joints(0.07,0.10);
    auto noise_joints = std::bind ( distribution_joints, generator );

    //This determines the variation on experimental and initial data for local marker coordinate
    //distance i.e. a marker will be between 3 to 5 cm away from ground truth.
    std::uniform_real_distribution<> distribution_measurement_length(0.03,0.05);
    auto noise_measurement_length = std::bind( distribution_measurement_length, generator );

    //Random sign
    std::uniform_int_distribution<> distribution_sign(1,2); 
    auto noise_sign = std::bind( distribution_sign, generator );//Should be used like (noise_sign == 1 ? -1 : 1)


    //Create experimental positioning data.
    //Create model with markers and KDL datastructures.
    //Default marker coordinates are listed in the file dependencies/human_arm_marker.yaml
    MC::MCModel model_experimental(robot_description_tree, human_arm_chain, markers);
    //Determine number of time steps.
    int time_steps = 40;
    //Generate experimental joint configurations. These will also be target
    //values for optimisation.
    Eigen::MatrixXd q_experimental;
    //Resize to match number of joints. Will be 7 joints in total for arm.
    q_experimental.resize(human_arm_chain.getNrOfJoints(), time_steps);
    //Step size will change the variation of experimental measurement data from step to step.
    double time_step_size = 0.01;
    //Initialise to zero values
    q_experimental.setZero();
    for(int i = 0; i < time_steps; ++i)
    {
        //Sinusoidal signals for all experimental data. Range will
        //be slightly within the joint limits. Joint limits are found under
        //the dependencies/human_arm_description.xacro file.
        q_experimental.col(i)(0) = 1.82*sin(i * time_step_size) + 0.35;//1.92*sin(i * time_step_size) + 0.35;
        q_experimental.col(i)(1) = 1.47*sin(i * time_step_size) + 1.57;//1.57*sin(i * time_step_size) + 1.57;
        q_experimental.col(i)(2) = 2.78*sin(i * time_step_size) - 0.96;//2.88*sin(i * time_step_size) - 0.96;
        q_experimental.col(i)(3) = 1.035*sin(i * time_step_size) + 1.135;//1.135*sin(i * time_step_size) + 1.135;
        q_experimental.col(i)(4) = 1.47*sin(i * time_step_size);//1.57*sin(i * time_step_size);
        q_experimental.col(i)(5) = 0.205*sin(i * time_step_size) + 0.135;//0.305*sin(i * time_step_size) + 0.135;
        q_experimental.col(i)(6) = 0.51*sin(i * time_step_size);//0.61*sin(i * time_step_size);
    }
    //Save ground truth joint trajectory in file
    std::string groundtruth_q = "Ground truth joint trajectory";
    writeEigenToCSV(algorithm_result, groundtruth_q, q_experimental);

    //Set experimental marker local coordinates
    Eigen::VectorXd d_experimental;
    d_experimental.resize(3 * markers.size());

    //Set initial marker local coordinates
    Eigen::VectorXd d_init;
    d_init.resize(3 * markers.size());

    for(int i = 0; i < markers.size(); ++i)
    {
        //Experimental marker positions will be set to those defined in
        // dependencies/human_arm_markers.yaml
        Eigen::Vector3d marker_position = markers[i]->get_local_position();
        d_experimental(i * 3) = marker_position(0);
        d_experimental(i * 3 + 1) = marker_position(1);
        d_experimental(i * 3 + 2) = marker_position(2);
        
        //If statement to only add noise on certain markers with a given name.
        //If only certain markers with cetain parent frame needs to be adjusted
        // ex. Humerus then use markers[i]->get_parent_frame() instead.
        if(markers[i]->get_name() == "R.Bicep" 
            || markers[i]->get_name() == "R.Forearm" 
            || markers[i]->get_name() == "C7")
        {
            //Change factor on noise to add more or less.
            //Create random real vector
            Eigen::Vector3d noiseMeasurement(noise(), noise(), noise());
            //Adjust length of vector to be between 3 cm and 5 cm uniformly distributed.
            noiseMeasurement = noise_measurement_length() * noiseMeasurement/noiseMeasurement.norm();
            d_init.block(i * 3, 0, 3, 1) = marker_position + noiseMeasurement;  
        }
        else
        {
            d_init(i * 3) = marker_position(0);
            d_init(i * 3 + 1) = marker_position(1);
            d_init(i * 3 + 2) = marker_position(2);               
        }

    }
    //Write ground truth and intial local marker coordinates difference in file
    std::string d_d = "Initial distance from initial to ground truth local marker coordinates";
    algorithm_result << d_d << "\n";
    for(int i = 0; i < markers.size(); ++i)
    {
        algorithm_result << markers[i]->get_name() << "\n";
        algorithm_result << 
                            (d_experimental.block(i * 3, 0, 3, 1) 
                            - d_init.block(i * 3, 0, 3, 1)).norm()
                                          << "\n";
    }
    algorithm_result << "\n";
    


    //Will contain experimental marker positions at each timestep.
    Eigen::MatrixXd p_experimental;
    p_experimental.resize(markers.size() * 3, time_steps);

    //Create weighted matrix at each timestep.
    Eigen::MatrixXd Wi;
    Wi.resize(p_experimental.rows(), p_experimental.rows());
    //Set to identity matrix so that every marker position is currently used.
    Wi.setIdentity();
    Eigen::MatrixXd W(Wi.rows(), Wi.cols() * time_steps);
    for(int i = 0; i < time_steps; ++ i)
    {
        //Use MC::MCModel update method to get global marker position at each timestep. 
        //.block syntax -> .block(start row, start col, row size of block, col size of block).
        W.block(0, i * Wi.cols(), Wi.rows(), Wi.cols()) = Wi;
        //Goes through every time step of q_experimental
        model_experimental.update(q_experimental.col(i), d_experimental);
        //Gets the global marker positions generated from the MC::MCModel
        p_experimental.block(0, i, p_experimental.rows(), 1) = model_experimental.get_marker_positions();
    }

    //Ground truth global marker position trajectory written to file
    algorithm_result << "Ground truth global marker position trajectory" << "\n";
    for(int i = 0; i < markers.size(); ++i)
    {
        algorithm_result << markers[i]->get_name() << "\n";
        for(int j = 0; j < p_experimental.cols(); ++j)
        {   
            
            algorithm_result << p_experimental.block(i * 3, j, 3, 1).norm() << ",";
                                
        }
        algorithm_result << "\n";
    }

    algorithm_result << "\n";

    //Setup cadaver by creating new MC::MCModel
    std::cout << "Creating virtual and experimental model." << std::endl;
    std::shared_ptr<MC::MCModel> model(new MC::MCModel(robot_description_tree, human_arm_chain, markers));
    //Create optimiser
    MC::Local_Optimiser opt(model);
    //Initialise initial joint configuration
    Eigen::VectorXd q_init;
    q_init.setZero(human_arm_chain.getNrOfJoints());

    //Initial joint configuration will be the experimental joint configuration at time step 1
    // with added noise
    q_init <<   q_experimental.col(0)(0) + (noise_sign() == 1 ? -1 : 1) * noise_joints(),
                q_experimental.col(0)(1) + (noise_sign() == 1 ? -1 : 1)  * noise_joints(),
                q_experimental.col(0)(2) + (noise_sign() == 1 ? -1 : 1)  * noise_joints(), 
                q_experimental.col(0)(3) + (noise_sign() == 1 ? -1 : 1)  * noise_joints(),
                q_experimental.col(0)(4) + (noise_sign() == 1 ? -1 : 1)  * noise_joints(),
                q_experimental.col(0)(5) + (noise_sign() == 1 ? -1 : 1)  * noise_joints(), 
                q_experimental.col(0)(6) + (noise_sign() == 1 ? -1 : 1)  * noise_joints();
    //Write ground truth and initial marker difference to file
    std::string q_d = "Initial joint configuration differences from ground truth";
    Eigen::MatrixXd q_diff = q_experimental.col(0) - q_init;
    std::cout << q_d << "\n" << q_diff << std::endl;
    writeEigenToCSV(algorithm_result, q_d, q_diff);

    //Ready optimiser
    opt.init(q_init,d_init, p_experimental, W);
    //Run optimiser
    std::cout << "Optimising" << std::endl;
    opt.optimise();

    //Get results
    //MC::System_Coordinates is defined in include/model_fitting/local_optimiser.hpp
    //It contains pointer to the optimised joint configuration results and constant parameters
    MC::System_Coordinates sys = opt.get_system_coordinates();

    //Write optimal joint configuration to data file
    std::string opt_q = "Optimal joint configuration";
    writeEigenToCSV(algorithm_result, opt_q, *(sys.q));
    
    //Write Optimal local marker positions to data tile
    algorithm_result << "Optimal local marker coordinates position" << "\n";
    for(int i = 0; i < markers.size(); ++i)
    {   
        std::string marker_name = markers[i]->get_name();
        Eigen::MatrixXd marker_coordinates = sys.d->block(i * 3, 0 , 3, 1);
        writeEigenToCSV(algorithm_result, marker_name, marker_coordinates);                       
    }
    algorithm_result << "\n";

    //Show results in terminal
    std::cout << "Ground truth" << std::endl;
    std::cout << q_experimental << std::endl;
    std::cout << "Optimal" << std::endl;
    std::cout << *(sys.q) << std::endl;
    
    std::cout << "Deviation q" << std::endl;
    std::cout << q_experimental - *(sys.q) << std::endl;
    //Write deviation to csv file
    std::string q_deviation = "Optimal joint configuration deviation from ground truth";
    Eigen::MatrixXd q_opt_diff = q_experimental - *(sys.q);
    writeEigenToCSV(algorithm_result, q_deviation, q_opt_diff);
    //Show results in terminal
    std::cout << "Deviation d" << std::endl;
    for(int i = 0; i < markers.size(); ++i)
    {   
        std::cout << "Marker name: " << markers[i]->get_name() << std::endl;
        std::cout << (d_experimental - *(sys.d))(3 * i) << std::endl;
        std::cout << (d_experimental - *(sys.d))(3 * i + 1) << std::endl;
        std::cout << (d_experimental - *(sys.d))(3 * i + 2) << std::endl;
    }
    //Write deviation to csv file
    algorithm_result << "Optimal local marker coordinates deviation from ground truth" << "\n";
    for(int i = 0; i < markers.size(); ++i)
    {   
        algorithm_result << markers[i]->get_name() << "\n";
        algorithm_result << (d_experimental.block(i * 3, 0, 3, 1)
                             - sys.d->block(i * 3, 0 , 3, 1)).norm() << "\n";
                             
    }
    algorithm_result << "\n";
    
    //Calculate the position of each marker at each time step.
    Eigen::MatrixXd newpos(p_experimental.rows(), p_experimental.cols());
    for(int i = 0; i < sys.q->cols(); ++i)
    {
        //Using MC::MCModel to calculate marker positions
        model->update(sys.q->col(i), *(sys.d));
        newpos.col(i) = model->get_marker_positions();
    }
    
    //Show experimental marker position difference to optimised marker positions.
    std::cout << "Marker pos difference" << std::endl;
    std::cout << p_experimental - newpos << std::endl;
    std::cout << (p_experimental - newpos).norm() << std::endl;
    if((p_experimental - newpos).isZero(0.002))
    {
        //If difference is close enough that show message "same".
        std::cout << "Same" << std::endl;
    }
    //Write marker position deviation to file
    Eigen::MatrixXd p_diff = p_experimental - newpos;
    algorithm_result << "Optimal global marker coordinates deviation from ground truth at each time step" << "\n";
    for(int i = 0; i < markers.size(); ++i)
    {
        algorithm_result << markers[i]->get_name() << "\n";
        for(int j = 0; j < p_experimental.cols(); ++j)
        {   
            
            algorithm_result << p_diff.block(i * 3, j, 3, 1).norm() << ",";
                                
        }
        algorithm_result << "\n";
    }

    algorithm_result << "\n";

    algorithm_result.close();

    return 0;
}