#ifndef   MCMARKER_HPP
#define   MCMARKER_HPP
#include <string>
#include <eigen3/Eigen/Eigen>
#include <initializer_list>
#include <cassert>
namespace MC
{
    class Marker {
        //////////////////////////////////////////////////////////////
        /*
        Marker class to contain local position in reference to a parent
        frame. Class also contains name of marker.
        */
        //////////////////////////////////////////////////////////////
        public:
        Marker(std::string name, std::string parent_frame, std::initializer_list<double> l)
        {
            name_ = name;
            parent_frame_ = parent_frame;
            local_position_.x() = *l.begin();
            local_position_.y() = *(l.begin() + 1);
            local_position_.z() = *(l.begin() + 2);

        }
        const std::string& get_name() const
        {
            return name_;
        }
        const std::string& get_parent_frame() const 
        {
            return parent_frame_;
        }
        const Eigen::Vector3d& get_local_position() const
        {
            return local_position_;
        }
        double get_x() const
        {
            return local_position_.x();
        }
        double get_y() const
        {
            return local_position_.y();
        }
        double get_z() const
        {
            return local_position_.z();
        }
        //TODO OPERATOR OVERLOAD OF ().
        double& operator()(const int index)
        {
            assert(index >= 0 && index <= 2);
            if(index == 0)
            {
                return local_position_.x();
            }
            else if(index == 1)
            {
                return local_position_.y();
            }
            else if(index == 2)
            {
                return local_position_.z();
            }
        }
        private:
            std::string name_;
            std::string parent_frame_;
            Eigen::Vector3d local_position_;
            
    };
}
#endif