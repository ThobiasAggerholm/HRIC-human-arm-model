#ifndef KDL2EIG_HPP
#define KDL2EIG_HPP

#include <kdl/kdl.hpp>
#include <eigen3/Eigen/Eigen>

void kdl2eig(Eigen::Matrix3d &eig_m, const KDL::Rotation &kdl_m)
{
    for(int i = 0; i < 3; ++i)
    {
        for(int j = 0; j < 3; ++j)
        {
            eig_m(i, j) = kdl_m(i, j);
        }
    }
}
Eigen::Matrix3d kdl2eig(const KDL::Rotation &kdl_m)
{
    Eigen::Matrix3d eig_m;
    for(int i = 0; i < 3; ++i)
    {
        for(int j = 0; j < 3; ++j)
        {
            eig_m(i, j) = kdl_m(i, j);
        }
    }
    return eig_m;
}
void kdl2eig(Eigen::VectorXd &eig_v, const KDL::Vector &kdl_v)
{
    
    for(int i = 0; i < 3; ++i)
    {
        eig_v(i) = kdl_v(i);

    }
}
Eigen::Vector3d kdl2eig(const KDL::Vector &kdl_v)
{
    Eigen::Vector3d eig_v;
    
    for(int i = 0; i < 3; ++i)
    {
        eig_v(i) = kdl_v(i);

    }
    return eig_v;
}

#endif