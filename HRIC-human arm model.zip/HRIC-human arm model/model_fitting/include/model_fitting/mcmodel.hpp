#ifndef MCMODEL_HPP
#define MCMODEL_HPP
#include <vector>
#include <map>
#include <memory>
#include <cassert>

#include <kdl/kdl.hpp>
#include <kdl/treefksolverpos_recursive.hpp>
#include <kdl/treejnttojacsolver.hpp>

#include <eigen3/Eigen/Eigen>

#include <marker.hpp>
#include <kdl2eig.hpp>

namespace MC
{
    //////////////////////////////////////////////////////////////
    /*
    Model class to manage global marker positions and marker position
    derivatives with respect to rate of change of joint and scaling 
    parameters.
    */
    //////////////////////////////////////////////////////////////
    class MCModel
    {
        public:
        //////////////////////////////////////////////////////////////
        /*
        Assigns necessary data structures and creates a list containing
        KDL chain segment order.
        */
        //////////////////////////////////////////////////////////////
        MCModel(const KDL::Tree& tree, const KDL::Chain &chain, std::vector<std::shared_ptr<MC::Marker>>& markers_default)
        {
            tree_ = tree;
            markers_default_ = markers_default;
            //Three coordinates pr. marker.
            marker_positions_.resize(markers_default.size() * 3);
            //With respect to each joint.
            marker_velocity_q_.resize(markers_default.size() * 3, tree_.getNrOfJoints());
            //With respect to each marker scaling parameter. 3 scaling parameters pr. link and 3 pr. marker.
            marker_velocity_d_.resize(markers_default.size() * 3, markers_default_.size() * 3);

            fk_solver.reset(new KDL::TreeFkSolverPos_recursive(tree_));
            JntToJac_solver.reset(new KDL::TreeJntToJacSolver(tree_));

            //KDL chain segment order.
            for(int i = 0; i < chain.getNrOfSegments(); ++i)
            {
                name_chain_.push_back(chain.getSegment(i).getName());
            }

        }

        //Method updating marker positions and derivatives. Ensures 
        //dimensions of datastructures have not been changed.
        void update(const Eigen::VectorXd& q, const Eigen::VectorXd& d)
        {
            update_markers(d);
            update_position(q, d);
            update_velocity_q(q,d);
            update_velocity_d(q,d);
            assert(marker_positions_.size() == markers_default_.size() * 3);
            assert(marker_velocity_q_.rows() == markers_default_.size() * 3 &&
            marker_velocity_q_.cols() == tree_.getNrOfJoints());
            assert(marker_velocity_d_.rows() == markers_default_.size() * 3 &&
            marker_velocity_d_.cols() == markers_default_.size() * 3);

        }
     
        Eigen::VectorXd get_marker_positions()
        {
            return marker_positions_;
        }
        
        Eigen::MatrixXd get_marker_velocity_q()
        {
            return marker_velocity_q_;
        }
        
        Eigen::MatrixXd get_marker_velocity_d()
        {
            return marker_velocity_d_;
        }

        private:
        void update_markers(const Eigen::VectorXd& d)
        {
            for(int i = 0; i < d.rows(); i += 3)
            {
                (*markers_default_[i/3])(0) = d(i);
                (*markers_default_[i/3])(1) = d(i + 1);
                (*markers_default_[i/3])(2) = d(i + 2);
            }
        }
        //////////////////////////////////////////////////////////////
        /*
        Calculates each marker position based on equations (36) and (38)
        in report when given joint configuration q and scaling parameters
        d.
        */
        //////////////////////////////////////////////////////////////
        void update_position(const Eigen::VectorXd& q, const Eigen::VectorXd& d)
        {
            //Ensure that dimensions of joint configuration and scaling parameters
            //match dimensions of tree (chain) joints and segments.
            if(q.size() != tree_.getNrOfJoints() ||
                d.size() != markers_default_.size() * 3)
            {
                std::cout << q.size() << "X" << tree_.getNrOfJoints() << std::endl;
                std::cout << d.size() << "X" << markers_default_.size() * 3 << std::endl;
                throw("MCModel::update_position: Joint or scaling parameter dimensions are incorrect.");
            }

            //Explanation of segment.getFrameToTip()
            /*
                Given a joint relationship in urdf as so:
                <joint name="Ground_Clavicle" type="fixed">
                    <parent link="Ground"/>
                    <child link="Clavicle"/>
                    <origin xyz="0.025465 0.006325 0.00693" rpy = "0 0 1.5708"/>
                </joint> -- Note xyz has been changed for demonstration purposes.
                The method segment.getFrameToTip() on segment "Clavicle" will result in
                the position vector [0.025465; 0.006325; 0.00693] and rotation rpy [0 0 1.5708]. The position
                vector will be used as this represents the link that can get scaled.
                The position vector will be described with "Ground" as reference.
            */

            KDL::JntArray q_array;
            q_array.data = q;
            Eigen::Vector3d position;
            position.setZero();
            Eigen::Matrix3d rotation2base;
            Eigen::Matrix3d rotation2base_previous;
            KDL::Frame link_base;
            rotation2base_previous.setIdentity();
            for(int i = 0; i < name_chain_.size(); ++i)
            {            
                //Obtain rotation to current link
                fk_solver->JntToCart(q_array, link_base, name_chain_[i]);
                rotation2base = kdl2eig(link_base.M);

                //Assign marker global position and add any scaling to 
                //local marker position.
                for(int j = 0; j < markers_default_.size(); ++j)
                {
                    if(markers_default_[j]->get_parent_frame() == name_chain_[i])
                    {
                        marker_positions_.block(j * 3, 0, 3, 1) = 
                        kdl2eig(link_base.p) + rotation2base * markers_default_[j]->get_local_position();
                    }
                }

            }
        }
   
        //////////////////////////////////////////////////////////////
        /*
        Calculates marker rate of change with respect to rate of change
        of joint configuration q. Based on equation (34) in report.
        */
        //////////////////////////////////////////////////////////////
        void update_velocity_q(const Eigen::VectorXd& q, const Eigen::VectorXd& d)
        {
            //Go through every marker position.
            for(int i = 0; i < marker_positions_.size(); i+= 3)
            {   
                KDL::JntArray q_array;
                q_array.data = q;
                KDL::Frame link_base;
                fk_solver->JntToCart(q_array, link_base, markers_default_[i/3]->get_parent_frame());
                Eigen::VectorXd marker_coordinate = kdl2eig(link_base.M) * markers_default_[i/3]->get_local_position();
                //Create "some_matrix" that transforms from link rate of change
                //to marker rate of change.
                Eigen::Matrix<double, 3, 6> marker_velocity;
                marker_velocity.setZero();
                marker_velocity(0,0) = 1;
                marker_velocity(1,1) = 1;
                marker_velocity(2,2) = 1;
                marker_velocity(0,4) = marker_coordinate(2);
                marker_velocity(0,5) = -marker_coordinate(1);
                marker_velocity(1,3) = -marker_coordinate(2);
                marker_velocity(1,5) = marker_coordinate(0);
                marker_velocity(2,3) = marker_coordinate(1);
                marker_velocity(2,4) = -marker_coordinate(0);
                //Get jacobian to marker parent reference frame.
                KDL::Jacobian jac;
                jac.resize(tree_.getNrOfJoints());
                JntToJac_solver->JntToJac(q_array, jac, markers_default_[i/3]->get_parent_frame());
               
                
                //Update marker rate of change with respect to rate of change joint configuration vector.
                //.block syntax -> .block(start row, start col, row size of block, col size of block).
                marker_velocity_q_.block(i, 0, 3, tree_.getNrOfJoints()) = marker_velocity * jac.data;
                /*if(markers_default_[i/3]->get_parent_frame() == "Radius")
                {
                    std::cout << markers_default_[i/3]->get_name() << std::endl;
                    std::cout << "J_KDL^L: \n" << jac.data << "\n\n";
                    std::cout << "J_m10: \n" << marker_velocity_q_.block(i, 0, 3, tree_.getNrOfJoints()) << std::endl;
                    assert(3 == 1);
                }*/

            }
        }

        //////////////////////////////////////////////////////////////
        /*
        Calculates marker rate of change with respect to rate of change
        of scaling parameters d. Based on equation (37) and (39) in report.
        */
        //////////////////////////////////////////////////////////////
        void update_velocity_d(const Eigen::VectorXd& q, const Eigen::VectorXd& d)
        {            
            //Explanation of segment.getFrameToTip()
            /*
                Given a joint relationship in urdf as so:
                <joint name="Ground_Clavicle" type="fixed">
                    <parent link="Ground"/>
                    <child link="Clavicle"/>
                    <origin xyz="0.025465 0.006325 0.00693" rpy = "0 0 1.5708"/>
                </joint> -- Note xyz has been changed for demonstration purposes.
                The method segment.getFrameToTip() on segment "Clavicle" will result in
                the position vector [0.025465; 0.006325; 0.00693] and rotation rpy [0 0 1.5708]. The position
                vector will be used as this represents the link that can get scaled.
                The position vector will be described with "Ground" as reference.
            */
            KDL::Frame link_frame;
            KDL::JntArray q_array;
            q_array.data = q;

            //Go through each row first as each column will represent a
            //link segment number up until markers scaling.
            /*
            psi_d =
            [J_{d_{base link}}^m1  J_{d_Ground}^m1 ... J_{d_Hand}^m1 J_{d_m1}^m1 ... J_{d_mN}^m1;
            J_{d_{base link}}^m2  J_{d_Ground}^m2 ... J_{d_Hand}^m2 J_{d_m1}^m2 ... J_{d_mN}^m2;
            ...
            J_{d_{base link}}^mN  J_{d_Ground}^mN ... J_{d_Hand}^m2 J_{d_m1}^mN ... J_{d_mN}^mN;]
            */

            marker_velocity_d_.setZero();
            //std::cout << marker_velocity_d_.cols() << std::endl;
            for(int j = 0; j < marker_velocity_d_.cols(); j += 3)
            {

                fk_solver->JntToCart(q_array, link_frame, markers_default_[j/3]->get_parent_frame());
                marker_velocity_d_.block(j, j, 3, 3) = kdl2eig(link_frame.M);
                /*std::cout << "Parent frame: " << markers_default_[j/3]->get_parent_frame() << std::endl;
                std::cout << "Marker name: " << markers_default_[j/3]->get_name() << std::endl;
                std::cout << "Jacobian matrix: \n" << kdl2eig(link_frame.M) << std::endl;*/
            }
            /*std::cout << "Done" << std::endl;
            std::cout << "Full marker Jacobian_d \n" << marker_velocity_d_ << std::endl;
            assert(1 == 2);*/
            
        }   

        KDL::Tree tree_;
        std::vector<std::shared_ptr<MC::Marker>> markers_default_;
        std::unique_ptr<KDL::TreeFkSolverPos_recursive> fk_solver;
        std::unique_ptr<KDL::TreeJntToJacSolver> JntToJac_solver;

        std::vector<std::string> name_chain_;

        Eigen::VectorXd marker_positions_; //Reference base_link
        Eigen::MatrixXd marker_velocity_q_;
        Eigen::MatrixXd marker_velocity_d_;
        
    
        
    };
}
#endif