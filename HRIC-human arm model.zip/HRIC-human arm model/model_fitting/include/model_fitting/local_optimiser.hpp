#ifndef MCLOCALOPTIMISER_HPP
#define MCLOCALOPTIMISER_HPP
#include <memory>
#include <iostream>

#include <eigen3/Eigen/Eigen>

#include <mcmodel.hpp>

namespace MC
{
    struct System_Coordinates
    {
        Eigen::MatrixXd *q;
        Eigen::VectorXd *d;
    };
    //////////////////////////////////////////////////////////////
    /*
    MC::Local_Optimiser performs optimisation of objective function
    with arguments joint configuration and scaling parameters.
    Note currently only implementation of joint configuration 
    optimisation is implemented.
    */
    //////////////////////////////////////////////////////////////
    class Local_Optimiser
    {
        public:

        //Needs MC::MCModel to handle calculation of Psi, Psi_d and Psi_q.
        Local_Optimiser(const std::shared_ptr<MC::MCModel> &model_ptr)
        {
            model_ = model_ptr;
        }
        
        //Get initial configuration and experimental marker positions.
        void init(const Eigen::VectorXd &q_init, const Eigen::VectorXd &d_init,
                    const Eigen::MatrixXd &p_experimental, const Eigen::MatrixXd &W)
        {
            q_.resize(q_init.rows(), p_experimental.cols());
            q_.col(0) = q_init;
            d_ = d_init;
            p_experimental_ = p_experimental;

            G_q_.resize(q_init.size());
            G_d_.resize(d_init.size());
            G_qq_.resize(G_q_.rows(), q_init.size());
            G_dd_.resize(G_d_.rows(), d_init.size());
            G_dq_.resize(G_d_.rows(), q_init.size());
            
            //For sanity check
            /*std::cout << "Dimensions of G_q_: " << G_q_.rows() << "x" << G_q_.cols() << "\n"; 
            std::cout << "Dimensions of G_d_: " << G_d_.rows() << "x" << G_d_.cols() << "\n"; 
            std::cout << "Dimensions of G_qq_: " << G_qq_.rows() << "x" << G_qq_.cols() << "\n"; 
            std::cout << "Dimensions of G_dd_: " << G_dd_.rows() << "x" << G_dd_.cols() << "\n";
            std::cout << "Dimensions of G_dq_: " << G_dq_.rows() << "x" << G_dq_.cols() << std::endl;*/


            W_ = W;
                            
        }

        System_Coordinates get_system_coordinates()
        {
            System_Coordinates system_coordinates;
            system_coordinates.q = &q_;
            system_coordinates.d = &d_;
            return system_coordinates;
        }
        
        void optimise()
        {
            optimise_q_sequence();
            std::cout << "Initial joint configuration found." << std::endl;
            optimise_q_d_sequence();
        }
        
        void optimise_q_d_sequence()
        {
            /*std::cout << "Optimising with initial parameters q: \n" << q_ << "\n" << std::endl;
            std::cout << "d: \n" << d_ << "\n" << std::endl;*/

            while (true)
            {
                //Get sequence Matrices
                double G_sum = 0;

                Eigen::VectorXd G_d_sum(G_d_.rows());
                Eigen::MatrixXd G_dd_sum(G_dd_.rows(), G_dd_.cols());
                G_d_sum.setZero();
                G_dd_sum.setZero();
                Eigen::MatrixXd G_d_sequence(G_d_.rows(), q_.cols() * G_d_.cols());
                Eigen::MatrixXd G_q_sequence(G_q_.rows(), q_.cols() * G_q_.cols()); 
                Eigen::MatrixXd G_qq_sequence(G_qq_.rows(), q_.cols() * G_qq_.cols());
                Eigen::MatrixXd G_dq_sequence(G_dq_.rows(), q_.cols() * G_dq_.cols());

                for(int i = 0; i < q_.cols(); ++i)
                {
                    Eigen::MatrixXd Wi = W_.block(0, i * p_experimental_.rows(),
                    p_experimental_.rows(), p_experimental_.rows());

                    update_objective(q_.col(i), d_, Wi, p_experimental_.col(i));

                    G_sum += G_;
                    G_d_sum += G_d_;
                    G_dd_sum += G_dd_;
                    
                    G_d_sequence.block(0, i * G_d_.cols(), G_d_.rows(), G_d_.cols()) = G_d_;
                    G_q_sequence.block(0, i * G_q_.cols(), G_q_.rows(), G_q_.cols()) = G_q_;
                    G_qq_sequence.block(0, i * G_qq_.cols(), G_qq_.rows(), G_qq_.cols()) = G_qq_;
                    G_dq_sequence.block(0, i * G_dq_.cols(), G_dq_.rows(), G_dq_.cols()) = G_dq_;
                }

                //Check KKT conditions
                //Shows what tolerance is needed if optimisation gets stuck.
                std::cout << "Accuracy for optimal q and d " << G_d_sum.norm() << "X" << G_q_sequence.norm() << std::endl;
                if(G_q_sequence.isZero(0.01) && G_d_sum.isZero(0.005))
                {

                    return;
                }

                Eigen::VectorXd d_search = find_d_search(G_qq_sequence, G_dq_sequence,
                                                         G_dd_sum, G_q_sequence, G_d_sum);

                Eigen::MatrixXd q_search = find_q_search(G_qq_sequence, G_dq_sequence,
                                                            G_q_sequence, d_search);

                double t = backtraking_line_search_q_d(q_, d_, W_, p_experimental_, q_search,
                                                         d_search, G_q_sequence, G_d_sequence, G_sum, G_d_sum);

                q_ = q_ + t * q_search;
                d_ = d_ + t * d_search;
                /*
                if((t*q_search).isZero() && (t*d_search).isZero())
                {
                    std::cout << "No change" << std::endl;
                    std::cout << "t" << t << std::endl;
                    std::cout << "q: \n" << q_ << "\n" << std::endl;
                    std::cout << "d: \n" << d_ << "\n" << std::endl;
                    assert(1==2);
                }*/
            }
            
        }
        
        //Optimise with respect to q at every timestep.
        const Eigen::MatrixXd& optimise_q_sequence()
        {
            for(int i = 0; i < q_.cols(); ++i)
            {
                Eigen::VectorXd qi = q_.col(i);
                //.block syntax -> .block(start row, start col, row size of block, col size of block).
                optimise_q(qi, d_, W_.block(0, i * p_experimental_.rows(), p_experimental_.rows(), p_experimental_.rows()), p_experimental_.col(i));
                q_.col(i) = qi;
                if(i < q_.cols() - 1)
                {
                    //Set next initial joint configuration to previous optimised joint configuration.
                    q_.col(i + 1) = q_.col(i);
                }
                
            }
            return q_; //Optimised initial joint configuration.
        }

        //Optimise with respect to q.
        void optimise_q(Eigen::VectorXd &q, const Eigen::VectorXd &d,
                                const Eigen::MatrixXd &W, const Eigen::VectorXd &p_experimental)
        {
            //q will contain initial joint configuration value.
            //Update Objective function and derivatives.
            update_objective(q, d, W, p_experimental);
            //TESTING OF OBJECTIVE FUNCITONS//
            /*std::cout << "G: " << G_ << std::endl;
            std::cout << "G_q: \n" << G_q_ <<  "\n\n";
            std::cout << "G_d: \n" << G_d_ << "\n\n";
            std::cout << "G_qq: \n" << G_qq_ << "\n\n";
            std::cout << "G_dd: \n" << G_dd_ << "\n\n";
            std::cout << "G_dq: \n" << G_dq_ << "\n" << std::endl;
            //Stop program
            assert(1==2);*/
            //////////////////////////////////
            
            //Until KKT condition is satisfied
            std::cout << "Accuracy for initial joint configuration: " << G_q_.norm() << std::endl;
            while(!G_q_.isZero(0.01))
            {
                //Find search direction.
                Eigen::VectorXd search_direction;
                search_direction.resizeLike(q);
                search_direction = G_qq_.fullPivLu().solve(-G_q_);
                //Perform backtracking line search in direction of search_direction.
                double t = backtraking_line_search_q(q, d, W, p_experimental, search_direction);
                //Update joint configuration.
                q = q + t * search_direction;
                //std::cout << "Search direction \n" << search_direction << "\n";
                //std::cout << "New q: \n" << q << std::endl;
                //Update Objective function and derivatives.
                update_objective(q, d, W, p_experimental);

            }
            model_->update(q, d);
            //std::cout << "Difference \n" << p_experimental - model_->get_marker_positions() << std::endl;
            //std::cout << "Joint configuration \n" << q << std::endl;
        }

        //Calculates objective functions at q and d. Based on equations from report. First derivatives
        //are defined as gradient vectors.        
        void update_objective(const Eigen::VectorXd &q, const Eigen::VectorXd &d,
                                const Eigen::MatrixXd &W, const Eigen::VectorXd &p_experimental)
        {
            //Update MC::MCModel with joint configuration and scaling parameters.
            model_->update(q, d);
            //Define Psi from model data structures.
            Eigen::VectorXd psi = model_->get_marker_positions() - p_experimental;
            Eigen::MatrixXd psi_q = model_->get_marker_velocity_q();
            Eigen::MatrixXd psi_d = model_->get_marker_velocity_d();

            //Calculate Objective function and derivatives. Note first
            //derivatives are defined as column vectors.
            //Based on equations in report.
            G_ = 0.5 * psi.transpose() * W * psi;
            G_q_ = psi_q.transpose() * W * psi;
            G_d_ = psi_d.transpose() * W * psi;
            G_dd_ = psi_d.transpose() * W * psi_d;
            //Performs numerical calculation to determine second derivatives.
            update_G_qq(q, d, W, p_experimental);
            update_G_dq(q, d, W, p_experimental);

            assert(G_q_.size() == q.size());
            assert(G_d_.size() == d.size());
            assert(G_qq_.rows() == G_q_.rows() && G_qq_.cols() == q.size());
            assert(G_dd_.rows() == G_d_.rows() && G_dd_.cols() == d.size());
            assert(G_dq_.rows() == G_d_.rows() && G_dq_.cols() == q.size());
            
        }

        void update_G_qq(const Eigen::VectorXd &q, const Eigen::VectorXd &d,
                         const Eigen::MatrixXd &W, const Eigen::VectorXd &p_experimental)
        {
            //Direction vector
            Eigen::VectorXd j;
            j.resizeLike(q);
            j.setZero();
            //Step size
            double q_delta = 0.001;
            
            
            for(int i = 0; i < j.rows(); ++i)
            {
                if(i != 0)
                {
                    j(i -1) = 0;
                }
                j(i) = 1;
                //Update model in direction of j for q.
                model_->update(q + q_delta * j, d);
                //Calculate new G_q
                Eigen::VectorXd psi = model_->get_marker_positions() - p_experimental;
                Eigen::MatrixXd psi_q = model_->get_marker_velocity_q();
                Eigen::VectorXd G_q_delta = psi_q.transpose() * W * psi;
                //Insert in G_qq_
                //.block syntax -> .block(start row, start col, row size of block, col size of block).
                G_qq_.block(0, i * G_q_.cols(), G_q_.rows(), G_q_.cols()) 
                = ((G_q_delta - G_q_)/q_delta);
                
            }
            //Reset state for to original model state.
            model_->update(q, d);
        }

        void update_G_dq(const Eigen::VectorXd &q, const Eigen::VectorXd &d,
                         const Eigen::MatrixXd &W, const Eigen::VectorXd &p_experimental)
        {
            //Direction vector
            Eigen::VectorXd j;
            j.resizeLike(q);
            j.setZero();
            //Step size
            double q_delta = 0.001;
            
            
            for(int i = 0; i < j.rows(); ++i)
            {
                if(i != 0)
                {
                    j(i -1) = 0;
                }
                j(i) = 1;
                //Update model in direction of j for q.
                model_->update(q + q_delta *j, d);
                //Calculate new G_q
                Eigen::VectorXd psi = model_->get_marker_positions() - p_experimental;
                Eigen::MatrixXd psi_d = model_->get_marker_velocity_d();

                Eigen::VectorXd G_d_delta = psi_d.transpose() * W * psi;
                //Insert in G_qd_
                //.block syntax -> .block(start row, start col, row size of block, col size of block).
                G_dq_.block(0, i * G_d_.cols(), G_d_.rows(), G_d_.cols()) 
                = (G_d_delta - G_d_)/q_delta;
            }
            //Reset state for to original model state.
            model_->update(q, d);
        }

        double backtraking_line_search_q(const Eigen::VectorXd& q, const Eigen::VectorXd &d,
                                const Eigen::MatrixXd &W, const Eigen::VectorXd &p_experimental,
                                const Eigen::VectorXd& search_direction)
        {
            double alpha = 0.2;
            double beta = 0.35;
            double t = 1;
            double G_delta;
            while(true)
            {
                //Go step t in search direction and update model.
                model_->update(q +  t * search_direction, d);
                //Determine new function value.
                Eigen::VectorXd psi = model_->get_marker_positions() - p_experimental;
                G_delta = 0.5 * psi.transpose() * W * psi;
                //Check if new function value is lower than value at discounted gradient.
                if(!(G_delta > G_ + alpha * t * G_q_.transpose() * search_direction))
                {
                    break;
                }
                //Take smaller step sizes.                
                t *= beta;
            }
            //Reset state for to original model state.
            model_->update(q,d);
            return t;
        }
        
        double backtraking_line_search_q_d(const Eigen::MatrixXd& q, const Eigen::VectorXd &d,
                                const Eigen::MatrixXd &W, const Eigen::MatrixXd &p_experimental,
                                const Eigen::MatrixXd &q_search, const Eigen::VectorXd &d_search,
                                const Eigen::MatrixXd &G_q_sequence, const Eigen::MatrixXd &G_d_sequence,
                                const double G, const Eigen::VectorXd &G_sum)
        {
            double alpha = 0.2;
            double beta = 0.45;
            double t = 1;
            while(true)
            {
                double G_delta = 0;
                double gradient_step = 0;
                Eigen::MatrixXd Wi;
                for(int i = 0; i < q.cols(); ++i)
                {
 
                    Wi = W_.block(0, i * p_experimental_.rows()
                                , p_experimental_.rows(), p_experimental_.rows());

                    //Go step t in search direction and update model.
                    model_->update(q.col(i) +  t * q_search.col(i), d + t * d_search);

                    //Determine new function value.
                    Eigen::VectorXd psi = model_->get_marker_positions() - p_experimental.col(i);

                    G_delta += 0.5 * psi.transpose() * Wi * psi;

                    gradient_step = gradient_step + alpha * t * G_q_sequence.col(i).transpose() * q_search.col(i)
                                    + alpha * t * G_d_sequence.col(i).transpose() * d_search;        

                }

                //Check if new function value is lower than value at discounted gradient.
                if(!(G_delta > G + gradient_step))
                {
                    break;
                }
                //Take smaller step sizes.                
                t *= beta;
                
                /*if(t < 0.0000000000000000001)
                {   
                    std::cout << "Mags" << std::endl;
                    std::cout << G_q_sequence.norm() << std::endl;
                    std::cout << G_sum.norm() << std::endl;
                    std::cout << "Step size too small" << std::endl;
                    std::cout << "q: \n" << q_ << "\n" << std::endl;
                    std::cout << "d: \n" << d_ << "\n" << std::endl;
                    assert(1 == 2);
                }*/
                    
            }
            //Reset state for to original model state.
            model_->update(q.col(q.cols() -1),d);
            return t;
        }
   
        Eigen::VectorXd find_d_search(const Eigen::MatrixXd &A, const Eigen::MatrixXd &B,
                                        const Eigen::MatrixXd &C, const Eigen::MatrixXd &a,
                                        const Eigen::VectorXd &b)
        {
            Eigen::MatrixXd B_Ainv_BT_sum;
            B_Ainv_BT_sum.setZero(G_dq_.rows(), G_dq_.rows());
            Eigen::MatrixXd B_Ainv_a_sum;
            B_Ainv_a_sum.setZero(G_dq_.rows(), G_q_.cols());
            for(int i = 0; i < q_.cols(); ++i)
            {
                Eigen::MatrixXd Bi = B.block(0, i * G_dq_.cols(), G_dq_.rows(), G_dq_.cols());
                Eigen::MatrixXd B_Ainv 
                = Bi * A.block(0, i * G_qq_.cols(), G_qq_.rows(), G_qq_.cols()).inverse();

                B_Ainv_BT_sum += B_Ainv * Bi.transpose();
                B_Ainv_a_sum += B_Ainv * a.block(0, i * G_q_.cols(), G_q_.rows(), G_q_.cols());
            }
            
            return (-B_Ainv_BT_sum + C).fullPivLu().solve(-b + B_Ainv_a_sum);
        }

        Eigen::MatrixXd find_q_search(const Eigen::MatrixXd &A, const Eigen::MatrixXd &B,
                                        const Eigen::MatrixXd &a, const Eigen::VectorXd &d_search)
        {
            Eigen::MatrixXd q_search(q_.rows(), q_.cols());
            for(int i = 0; i < q_.cols(); ++i)
            {
                Eigen::MatrixXd Ainv_i = A.block(0, i * G_qq_.cols(), G_qq_.rows(), G_qq_.cols()).inverse();
                Eigen::MatrixXd ai = a.block(0, i * G_q_.cols(), G_q_.rows(), G_q_.cols());
                Eigen::MatrixXd BT = B.block(0, i * G_dq_.cols(), G_dq_.rows(), G_dq_.cols()).transpose();
                
                q_search.block(0, i, q_.rows(), 1) = -Ainv_i * ai -Ainv_i * BT * d_search;
            }
            return q_search;
        }

        private:
        std::shared_ptr<MC::MCModel>model_;
        Eigen::MatrixXd q_;
        Eigen::VectorXd d_;
        Eigen::MatrixXd p_experimental_;

        double G_;
        Eigen::VectorXd G_q_;
        Eigen::VectorXd G_d_;
        Eigen::MatrixXd G_qq_;
        Eigen::MatrixXd G_dd_;
        Eigen::MatrixXd G_dq_;

        Eigen::MatrixXd W_;


    };
}

#endif