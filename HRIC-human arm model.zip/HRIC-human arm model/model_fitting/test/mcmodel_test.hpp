#ifndef MCMODEL_TEST_HPP
#define MCMODEL_TEST_HPP
#include <iostream>
#include <memory>
#include <vector>
#include <cassert>

#include <kdl/kdl.hpp>
#include <kdl/chainfksolverpos_recursive.hpp>

#include <eigen3/Eigen/Eigen>

#include <mcmodel.hpp>
#include <marker.hpp>

#include <kdl2eig.hpp>

namespace MC {
    
    class MCModel_Tester
    {
        //////////////////////////////////////////////////////////////
        /*
        Class for testing MC::MCModel. Currently tests marker position
        when scaling is not applied.
        */
        //////////////////////////////////////////////////////////////
        public:
            MCModel_Tester(const std::shared_ptr<MC::MCModel> &model, const KDL::Chain &chain, const std::vector<std::shared_ptr<MC::Marker>> &markers)
            {
                model_ = model;
                chain_ = chain;
                markers_ = markers;
                fk_solver.reset(new KDL::ChainFkSolverPos_recursive(chain_));


                //Map markers to segments
                for(int i = 0; i < chain_.getNrOfSegments(); ++i)
                {
                    const KDL::Segment segment_i = chain_.getSegment(i);
                    name_to_nr[segment_i.getName()] = i;
                }
            }
            //Uses the forward kinematics solver to calculate global marker positions.
            void test_position(const Eigen::VectorXd &q, const Eigen::VectorXd &d)
            {
                Eigen::VectorXd d_one;
                d_one.resizeLike(d);
                d_one.setOnes();
                assert(d_one.isApprox(d));
                
                model_->update(q, d_one);
                Eigen::VectorXd model_marker_positions;
                model_marker_positions = model_->get_marker_positions();

                Eigen::VectorXd tester_marker_positions;
                tester_marker_positions.resize(3 * markers_.size(), 1);
                for(int i = 0; i < 3 * markers_.size(); i += 3)
                {
                    KDL::Frame frame;
                    KDL::JntArray q_jnt;
                    q_jnt.data = q;
                    fk_solver->JntToCart(q_jnt, frame, 1 + name_to_nr[markers_[i/3]->get_parent_frame()]);
                    tester_marker_positions.block(i, 0, 3, 1) = kdl2eig(frame.p)
                                                                +  kdl2eig(frame.M)
                                                                * markers_[i/3]->get_local_position();
                }
                
                if(!tester_marker_positions.isApprox(model_marker_positions))
                {
                    std::cout << "Marker positions are not equal." << std::endl;
                    Eigen::MatrixXd compare(model_marker_positions.rows(), 2);
                    compare.block(0,0, model_marker_positions.rows(), 1) = model_marker_positions;
                    compare.block(0,1, model_marker_positions.rows(), 1) = tester_marker_positions;
                    std::cout << compare << std::endl;
                    throw("Not correct marker positions");
                }
                std::cout << "Marker positions are equal" << std::endl;


            }
        private:
        KDL::Chain chain_;
        std::vector<std::shared_ptr<MC::Marker>> markers_;
        std::shared_ptr<MC::MCModel> model_;
        std::unique_ptr<KDL::ChainFkSolverPos_recursive> fk_solver;
        std::map<std::string, int> name_to_nr;
    };

}

#endif